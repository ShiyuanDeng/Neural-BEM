# TOP-018 handoff — qualify resolution, then finish the two-star comparison

Prepared 2026-09-15. This package reviews TOP-017 at
`243fe19a7937dd519c4a55bc3e04d464ee04d2a4` on
`feature/ordered-boundary-nystrom`. It contains instructions, not new numerical
results or execution approval.

## The decision

Keep the qualified central-case recovery. Do not rerun it or erase it behind the
campaign's overall no-promotion flag. The remaining two-star experiment stopped
at resolution checks, not a demonstrated recovery failure. Authorize one bounded
resolution audit and, only if it passes, one matched higher-resolution S/F pair.
No new optimizer, topology policy, frequency search, merge inverse, or suite.

TOP-018's S/F trials deliberately start from the same previously saved common
low-frequency endpoint, not from the different stopped S/F endpoints. This is a
new, matched discretization experiment; it is not a bitwise resume of TOP-017.

## Install here

Merge these NEW files into the repository; do not replace existing history:

```text
docs/iterations/topology/iteration_11/
  01_results.md                         # existing: leave intact
  02_proposals/
    01_TOP017_review_and_resolution_decision.md
  03_plan.md
```

`START_HERE.md`, `PACKAGE_MANIFEST.json` and `SHA256SUMS.txt` describe this package.
They need not become another maintained repository-document layer.

If any destination is now occupied, inspect the current work and reconcile
without overwriting it. If TOP-018 already exists, stop before numeric work and
report the conflict rather than silently reusing its ID.

## Current Git instructions — important change from the previous package

Read root `AGENTS.md` first. At the reviewed commit the user's default is:

- working directory `/home/drdeng/Neural_SDF_BEM_AD`;
- existing branch `feature/ordered-boundary-nystrom`;
- no new branch or worktree without the user's direct, explicit permission for
  that creation. Experiment approval does not supply that permission.

Use the existing checkout. Have only one source-code writer. A second reviewer
can inspect read-only, and numerical subprocesses can use separate output
folders without creating Git worktrees. Freeze numerical source before dispatch;
no agent edits measured code while trials are running. Do not resurrect deleted
TOP-016/017 branches just because historical plans name them.

Preserve user edits. Do not reset, clean, stash, discard, switch branches, pull,
push, merge, or delete branches automatically. Commit only this task's validated
work when authorized below; never sweep unrelated edits into that commit.

## Agent prompt

The user can issue this prompt after installing the package. Its approval is of
the numerical scope, not permission to create a branch/worktree or push:

```text
Read AGENTS.md, docs/iterations/README.md, the shared implementation principles,
and the two new documents under docs/iterations/topology/iteration_11.

I approve TOP-018 exactly as scoped and budgeted in iteration_11/03_plan.md.
Use the existing /home/drdeng/Neural_SDF_BEM_AD checkout and existing
feature/ordered-boundary-nystrom branch. Do not create a branch or worktree.

Record this approval and actual owner/reviewer. Review the implementation once,
then execute Phase A and proceed to the two Phase-B trials only if its written
gate passes. Do not ask for repeated approval of these same conditional stages.
Resolve mechanical details from the code; never from truth/evaluation scores.

Do not repeat the central inverse, historical common low-frequency stage,
information screens, oracle generation, or merge projection audit. Preserve
TOP-017's central success, its two-star obstructions, and TOP-016's merge
regression. Do not relax numerical tolerances or redesign the solver/optimizer.

If a gate, hard resource ceiling, or numerical check stops the experiment,
retain the evidence and close out. No unplanned resolution ladder, restarts,
new controls, full suite, or automatic successor is authorized.

Finish with the result bundle, iteration_12/01_results.md, current handoffs,
and one justified next decision. Commit validated task changes on the existing
branch. Do not push or merge unless I separately ask.
```

If no explicit approval is supplied, the agent may read, review, and integrate
documents, but the plan remains `PROPOSED — NOT APPROVED FOR EXECUTION`.

## Expected deliverable

A small audit table and a two-arm scorecard, not a new framework. Phase A costs
at most 256 attempted frequency solves; Phase B, if released, permits at most
7,000 per arm. Every numerical limit, state-selection rule, and final decision
criterion is in `03_plan.md`. A failed Phase A is a valid complete closeout.
