# Install and hand off TOP-016

Prepared 2026-09-14 for `ShiyuanDeng/Neural-BEM`, branch `feature/ordered-boundary-nystrom`.
Reviewed head: `9acae6bac060e84704d938e9a1e63407971841e7`.

## Where the files go

**Do not open iteration 10 yet.** The repository's convention is that new proposals and their consolidated plan stay in the current cycle; executed results open the next cycle. Iteration 09 already has results and three proposals but no consolidated plan at the reviewed revision.

Copy the package's `docs/` subtree into the repository, preserving these paths:

```text
docs/iterations/
  implementation_principles.md
  topology/iteration_09/
    02_proposals/
      04_recovery_reset_review.md
    03_plan.md
```

All three are new paths at the reviewed revision. Extract the archive outside the repository first and check the current checkout before copying. Do not overwrite an agent's newer or uncommitted work. This `START_HERE.md` is a handoff note; it need not be installed as another repository document.

| File | Role |
|---|---|
| `implementation_principles.md` | Reusable research/implementation discipline across tracks; complements the existing shared workflow |
| `04_recovery_reset_review.md` | Evidence corrections, literature rationale, and explicit decisions on TOP-013/014/015 |
| `03_plan.md` | Proposed TOP-016 contract: inputs, matched arms, information screen, pilot, budgets, tests and closeout |

Do not replace the existing TOP-013/014/015 proposal bodies. The agent should add only a dated TOP-015 supersession status after adoption and record the other proposals as deferred/not selected.

## What agents should do to integrate the documents

Add a short link to `implementation_principles.md` from `docs/iterations/README.md`. Keep the existing workflow, approval rules and histories; do not create another parallel management framework.

Update `docs/iterations/topology/README.md` and `docs/README.md` so they acknowledge the recorded completion of TOP-011/012, identify iteration 09 as the active planning cycle, and link the new review and TOP-016 plan. Preserve the distinction between an approved experiment and a completed one. Do not mark the new plan APPROVED until the user actually sends the approval below or equivalent instructions.

Root `AGENTS.md` contains user preferences. Preserve it. The task prompt below already routes the agents to the relevant documents; no broad AGENTS rewrite is needed.

After TOP-016 finishes, its measured result or obstruction belongs in `docs/iterations/topology/iteration_10/01_results.md`. Detailed artifacts stay under the fresh TOP-016 result bundle. A twelve-scene qualification is a possible next-cycle decision, not an extra stage silently authorized by this package.

## Copy-paste prompt for the implementation agent

```text
Read AGENTS.md, docs/iterations/README.md, and the three newly installed files:
- docs/iterations/implementation_principles.md
- docs/iterations/topology/iteration_09/02_proposals/04_recovery_reset_review.md
- docs/iterations/topology/iteration_09/03_plan.md

I approve TOP-016 as scoped and budgeted in that plan and adopt the shared implementation principles. This approval covers the documentation integration, implementation preflight, binding information screen, paired fixed-topology pilot, its explicitly bounded local control, and closeout. It does not approve TOP-013/014/015, a new optimizer or topology policy, or a full twelve-scene suite.

Check the current branch and working tree without discarding anything. Record this approval and the actual owner/reviewer, create the experiment worktree, and perform one implementation preflight review. Use an independent reviewer where available; otherwise record that limitation rather than inventing a review. Resolve implementation details using the code and numerical checks, not truth or held-out scores.

Proceed through the approved stages when their gates pass without asking me to reapprove the same scope. Stop a failed or inconclusive stage as the contract specifies; do not expand the budgets or launch adjacent experiments. Preserve existing defaults and all historical observations/results.

Commit validated work on the experiment branch. Do not push or merge unless I separately ask. Finish with the result bundle, iteration_10/01_results.md, updated handoffs, and a concise account of what worked, what failed, the cost, and the single next decision. Do not automatically begin another cycle.
```

## What this package deliberately does not do

It does not claim that TOP-016 has been approved, implemented or run merely because these files exist. It does not change any repository file remotely. It does not promise that the proposed frequency range recovers every shape.

The outcome should answer whether a bounded fixed-topology continuation is worth qualifying, while avoiding another chain of optimizer or controller modifications justified only by lower training loss.
