# Start here — TOP-017 instruction pack

Prepared 2026-09-14 after reviewing TOP-016 at
`9ad3c8b191c7f1130764c0476480290b0f6a6e4a` on `track/topology-TOP-016`.

## Decision in one paragraph

TOP-016's information screen passed, but the two principal comparisons stopped
before any added frequency entered optimization. The completed merge control
regressed. TOP-017 reuses the shared 0.5-GHz endpoints and runs only the remaining
principal stages, with an explicit distinction between stage quotas and hard
trial limits. A small, non-optimization audit checks the omitted merge
representation assumption. It does not authorize a new optimizer, topology
policy, principal bandwidth, data acquisition, or full benchmark suite.

## Where the files go

Merge the included `docs/` subtree into the matching repository paths:

```text
docs/iterations/topology/iteration_10/
├── 01_results.md                         # already exists; keep it
├── 02_proposals/
│   ├── 01_TOP016_review_and_next_steps.md # new
│   └── 02_staged_execution_addendum.md   # new
└── 03_plan.md                            # new; proposed TOP-017 contract
```

The current iteration is **10**, not 11. TOP-017's execution closeout opens
iteration 11, even if its result is negative or inconclusive. No new results
file is included in this pack. Do not overwrite TOP-016's executed iteration-09
plan, iteration-10's results, historical bundles, or the existing shared
`implementation_principles.md`.

`START_HERE.md` is a package handoff and need not be installed as another
repository document. `PACKAGE_MANIFEST.json` and `SHA256SUMS.txt` allow integrity
checks. Extract the ZIP into a temporary directory first; compare any existing
destination before copying. A name collision means inspect current work, not
silently replace it or renumber everything.

## Important branch detail

The reviewed new results and optimizer hooks are on **track/topology-TOP-016**.
At review time the feature branch still pointed to `d3bbdae`; it did not contain
that completed experiment. Start the successor worktree from the reviewed
TOP-016 revision, or a checked descendant containing it, **not** blindly from
the older feature branch.

After approval, create `track/topology-TOP-017` in its own worktree and install
the docs there. Fetch remote refs as needed; do not reset, discard, stash or
rebase somebody else's uncommitted work. If the experiment branch already
exists, inspect its status and artifacts instead of recreating it. Do not
merge TOP-016 into the feature branch merely to make this installation work.

## Agent prompt — user authorization when issued

The files remain PROPOSED until the user issues an approval. The following
prompt approves only the included scope and budgets:

```text
Read this TOP-017 pack's START_HERE.md and the three included Markdown
files, plus the repository's AGENTS.md, docs/iterations/README.md and
existing implementation_principles.md.

I approve TOP-017 exactly as scoped and budgeted in iteration_10/03_plan.md,
and adopt its staged-execution amendment. This does not approve a full
suite, a new optimizer or topology policy, or any successor experiment.

Inspect current refs/worktrees without discarding work. The reviewed base
is 9ad3c8b191c7f1130764c0476480290b0f6a6e4a on track/topology-TOP-016;
do not start from a feature branch that lacks TOP-016. Create or safely
resume the separate track/topology-TOP-017 worktree, check intervening
changes and install the new docs without overwriting later work.

Record this approval and actual owner/reviewer assignments. Perform one
implementation review, independently where available; do not invent a
review. Link the amendment from the shared principles and update the
handoffs/dashboard. Test the stage-quota versus hard-stop semantics with
mocked forwards before spending physical solves.

Execute the approved Phase A and, if its gates pass, the four principal
continuation trials. Reuse TOP-016's retained paired endpoints, observations
and passed screens. Do not rerun the common 0.5-GHz stage. Do not ask for
reapproval at valid stage transitions within this contract.

Preserve the merge regression, all old evidence and numerical defaults.
Do not change principal K=9, optimizer mathematics, derivative method,
frequency set, evaluation gates or hard budgets. Only planned stage quotas
can advance; global limits and numerical/implementation failures stop.
No extra seeds, local controls, merge inverse or full suite are included.

Close out with a reproducible bundle, complete exposure/work/quality
scorecard, honest missing diagnostics and iteration_11/01_results.md.
Choose one next decision; do not automatically begin another cycle.
Commit validated work locally. Do not push, merge or delete branches
unless I separately instruct it.
```

The implementing agent should choose real function/flag names from the code;
the plan states numerical invariants and scope rather than prescribing an
unverified API. A failed gate is a result to preserve, not authority to expand
the experiment.
