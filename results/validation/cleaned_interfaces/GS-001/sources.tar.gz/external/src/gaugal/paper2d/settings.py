"""Typed, resolved settings for one reproducible paper case."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PaperCaseSettings:
    """Case-dependent values; solver mechanics remain fixed in paper_options."""

    lambda_scale: float
    sigma_scale: float
    step_size: float
    contrast_max: float
    grid_size: int
    num_iter: int
    tv_max_iter: int
    lambda_schedule: str
    lambda_final_fraction: float
    lambda_decay_start_fraction: float


@dataclass(frozen=True)
class SolverControls:
    """Shared controls for the 2-D reconstruction."""

    num_iter: int | None = None
    tv_max_iter: int | None = None
    pcg_tol: float = 1e-4
    pcg_max_iter: int = 100
    collocation_chunk_size: int = 64
    collocation_quadrature_order: int = 6
    bicgstab_mode: str = "sync"
    bicgstab_sync_every: int = 4
    bicgstab_fixed_iter: int = 8
    reuse_fft_workspace: bool = True
    profile: bool = False
