"""Project SingleTX MNIST and Cylinder fields onto a Gaussian lattice."""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter

import numpy as np
import torch

from .collocation import (
    CollocationOptions,
    GaussianCollocationModel,
    _compute_mass_lump,
    _harmonic_factorize_external,
    _linear_conv2d_fft,
    _matrix_to_lattice_kernel_fft,
    _resolve_collocation_external_operator,
    _resolve_collocation_linear_solver_name,
    _resolve_contrast_mode,
    _separable_pixels_to_coeff,
)


@dataclass
class SyntheticScatteringModel:
    """Pixel-grid synthetic measurements and their projected Green operator."""

    file_name: str
    frequency_ghz: float
    wavelength: float
    kb: float
    length: float
    nx: int
    ny: int
    dx: float
    dy: float
    x: torch.Tensor
    y: torch.Tensor
    xx: torch.Tensor
    yy: torch.Tensor
    data: torch.Tensor
    receiver_mask: torch.Tensor
    uinc: torch.Tensor
    nominal_truth: torch.Tensor
    dense_g: torch.Tensor
    dense_h: torch.Tensor
    pixel_points: torch.Tensor
    x_transmit: torch.Tensor
    y_transmit: torch.Tensor
    x_receive: torch.Tensor
    y_receive: torch.Tensor
    amp: complex = 1.0 + 0.0j
    domain_kernel_fft: torch.Tensor | None = None

    @property
    def device(self) -> torch.device:
        return self.data.device

    @property
    def dtype(self) -> torch.dtype:
        return self.data.dtype

    @property
    def real_dtype(self) -> torch.dtype:
        return self.x.dtype

    @property
    def cell_area(self) -> float:
        return self.dx * self.dy

    @property
    def num_transmitters(self) -> int:
        return self.uinc.shape[0]

    @property
    def num_receivers(self) -> int:
        return self.data.shape[1]


def build_synthetic_galerkin_model(
    model: SyntheticScatteringModel, opts: CollocationOptions
) -> GaussianCollocationModel:
    """Project a synthetic scene onto a fixed Gaussian lattice."""
    if opts.collocation_grid_size < 2:
        raise ValueError("collocation_grid_size must be at least 2")

    start = perf_counter()
    grid_size = opts.collocation_grid_size
    centers, sigma, source_area, target_indices = _make_synthetic_lattice_basis(
        model, grid_size, opts.collocation_sigma_scale
    )
    return _assemble_synthetic_galerkin_model(
        model,
        opts,
        centers,
        sigma,
        source_area,
        target_indices,
        grid_size=grid_size,
        start=start,
    )


def _assemble_synthetic_galerkin_model(
    model: SyntheticScatteringModel,
    opts: CollocationOptions,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
    target_indices: torch.Tensor,
    *,
    grid_size: int,
    start: float,
) -> GaussianCollocationModel:
    empty_complex = torch.empty((0, 0), device=model.device, dtype=model.dtype)
    empty_real = torch.empty(0, device=model.device, dtype=model.real_dtype)
    k_kernel_fft = empty_complex
    mass_kernel_fft = empty_complex
    domain_kernel_fft = empty_complex
    operator_basis_weights = None
    operator_basis_y_weights = None
    operator_basis_x_weights = None
    render_y_weights = None
    render_x_weights = None
    separable_mass_y_inverse = None
    separable_mass_x_inverse = None
    domain_grid_size = 0
    matvec_mode = _resolve_synthetic_matvec_mode(opts, grid_size * grid_size)
    collocation_contrast_mode = _resolve_contrast_mode(opts)
    external_operator = _resolve_collocation_external_operator(opts)
    r_harmonic_gamma = None
    r_harmonic_basis = None
    external_fit_rel_error = float("nan")
    use_separable_projection = opts.collocation_form == "galerkin" and matvec_mode == "fft"
    if use_separable_projection:
        # A(y, x) = A_y(y) A_x(x) avoids storing a pixel-by-basis matrix.
        basis_y, basis_x, render_y_weights, render_x_weights = _make_separable_basis_weights(
            model, centers, sigma, source_area, grid_size
        )
        basis_y_c = basis_y.to(model.dtype)
        basis_x_c = basis_x.to(model.dtype)
        r_matrix = _separable_pixels_to_coeff(model.dense_h, basis_y_c, basis_x_c)
        render_weights = empty_real
    else:
        basis_weights, render_weights = _make_dense_basis_weights(
            model, centers, sigma, source_area
        )
        operator_basis_weights = basis_weights
        basis_weights_c = basis_weights.to(model.dtype)
        r_matrix = _project_sensor_matrix(model.dense_h, basis_weights_c)

    if opts.collocation_form == "collocation":
        if matvec_mode == "fft":
            raise ValueError("FFT matvecs are only defined for Galerkin projection")
        if model.dense_g.numel() == 0:
            raise ValueError("Dense domain matrix was not loaded; use Galerkin FFT mode")
        k_matrix = model.dense_g[target_indices] @ basis_weights_c
        uinc = model.uinc[:, target_indices]
        mass_matrix = empty_complex
    elif opts.collocation_form == "galerkin":
        if matvec_mode == "fft":
            if opts.collocation_fft_assembly == "dense":
                raise ValueError(
                    "FFT Galerkin uses the domain kernel directly; use dense matvec "
                    "for dense projected assembly"
                )
            k_matrix = empty_complex
            mass_matrix = empty_complex
            if model.domain_kernel_fft is not None and model.domain_kernel_fft.numel() != 0:
                domain_kernel_fft = model.domain_kernel_fft
            elif model.dense_g.numel() != 0:
                domain_kernel_fft = _matrix_to_lattice_kernel_fft(model.dense_g, model.nx)
            else:
                raise ValueError("No domain kernel or dense matrix is available")
            operator_basis_y_weights = basis_y_c
            operator_basis_x_weights = basis_x_c
            domain_grid_size = model.nx
            # The iterative solver needs only these diagonals, not full matrices.
            k_diag, mass_diag = _build_separable_domain_diagonals(
                basis_y_c,
                basis_x_c,
                domain_kernel_fft,
                model.nx,
                model.cell_area,
                chunk_size=opts.collocation_chunk_size,
            )
        else:
            if model.dense_g.numel() == 0:
                raise ValueError("Dense domain matrix was not loaded; use Galerkin FFT mode")
            k_matrix = model.cell_area * (basis_weights_c.T @ (model.dense_g @ basis_weights_c))
            mass_matrix = (model.cell_area * (basis_weights.T @ basis_weights)).to(model.dtype)
            k_diag = torch.diagonal(k_matrix).clone()
            mass_diag = torch.diagonal(mass_matrix).clone()
        if use_separable_projection:
            uinc = model.cell_area * _separable_pixels_to_coeff(model.uinc, basis_y_c, basis_x_c)
        else:
            uinc = model.cell_area * (basis_weights_c.T @ model.uinc.T).T
    else:
        raise ValueError(f"Unknown collocation form: {opts.collocation_form}")

    if external_operator == "harmonic":
        if r_matrix.ndim != 2:
            raise ValueError("Harmonic external factorization requires a shared 2D R matrix")
        receiver_points = torch.stack([model.x_receive, model.y_receive], dim=1)
        (
            r_harmonic_gamma,
            r_harmonic_basis,
            external_fit_rel_error,
        ) = _harmonic_factorize_external(receiver_points, r_matrix, opts)
        r_matrix = empty_complex

    if opts.collocation_form != "galerkin":
        k_diag = torch.diagonal(k_matrix).clone()
        mass_diag = torch.ones(k_matrix.shape[0], device=model.device, dtype=model.dtype)

    basis_indices = torch.arange(centers.shape[0], device=model.device, dtype=torch.long)
    collocation = GaussianCollocationModel(
        centers=centers,
        sigma=sigma,
        source_area=source_area,
        basis_indices=basis_indices,
        source_cell_area=float(torch.mean(source_area).detach().cpu()),
        k_matrix=k_matrix,
        r_matrix=r_matrix,
        mass_matrix=mass_matrix,
        k_diag=k_diag,
        mass_diag=mass_diag,
        mass_lump=mass_diag.clone(),
        k_kernel_fft=k_kernel_fft,
        mass_kernel_fft=mass_kernel_fft,
        uinc=uinc,
        render_weights=render_weights,
        tv_scale=1.0 / min(model.dx, model.dy),
        grid_size=grid_size,
        form=opts.collocation_form,
        contrast_mode=collocation_contrast_mode,
        matvec_mode=matvec_mode,
        build_seconds=perf_counter() - start,
        basis_weights=operator_basis_weights,
        basis_y_weights=operator_basis_y_weights,
        basis_x_weights=operator_basis_x_weights,
        domain_kernel_fft=domain_kernel_fft,
        domain_grid_size=domain_grid_size,
        domain_cell_area=model.cell_area,
        render_y_weights=render_y_weights,
        render_x_weights=render_x_weights,
        separable_mass_y_inverse=separable_mass_y_inverse,
        separable_mass_x_inverse=separable_mass_x_inverse,
        r_harmonic_gamma=r_harmonic_gamma,
        r_harmonic_basis=r_harmonic_basis,
        external_operator=external_operator,
        external_fit_rel_error=external_fit_rel_error,
        reuse_fft_workspace=opts.collocation_reuse_fft_workspace,
        profile=opts.collocation_profile,
    )
    collocation.mass_lump = _compute_mass_lump(collocation)
    return collocation


def _resolve_synthetic_matvec_mode(opts: CollocationOptions, num_basis: int) -> str:
    if opts.collocation_matvec_mode not in {"dense", "fft"}:
        raise ValueError(f"Unknown collocation matvec mode: {opts.collocation_matvec_mode}")
    if opts.collocation_fft_assembly not in {"dense", "kernel"}:
        raise ValueError(f"Unknown FFT assembly mode: {opts.collocation_fft_assembly}")
    if opts.collocation_form != "galerkin":
        if opts.collocation_matvec_mode == "fft" or opts.collocation_fft_assembly == "kernel":
            raise ValueError("Kernel-only FFT assembly requires Galerkin projection")
        return "dense"

    linear_solver = _resolve_collocation_linear_solver_name(opts.collocation_form, num_basis, opts)
    if opts.collocation_matvec_mode == "fft":
        if linear_solver == "direct":
            raise ValueError("Kernel-only Galerkin requires the iterative kernel method")
        return "fft"
    if opts.collocation_fft_assembly == "kernel":
        raise ValueError("Kernel-only Galerkin requires the public galerkin-kernel method")
    return "dense"


def _build_separable_domain_diagonals(
    basis_y_weights: torch.Tensor,
    basis_x_weights: torch.Tensor,
    domain_kernel_fft: torch.Tensor,
    grid_size: int,
    cell_area: float,
    *,
    chunk_size: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Assemble Jacobi diagonals by applying the pixel FFT kernel in chunks."""
    mass_y = torch.sum(basis_y_weights * basis_y_weights, dim=0)
    mass_x = torch.sum(basis_x_weights * basis_x_weights, dim=0)
    mass_diag = cell_area * (mass_y[:, None] * mass_x[None, :]).reshape(-1)
    num_basis = basis_y_weights.shape[1] * basis_x_weights.shape[1]
    k_diag = torch.empty(num_basis, device=basis_y_weights.device, dtype=basis_y_weights.dtype)
    chunk = max(1, chunk_size)
    basis_indices = torch.arange(num_basis, device=basis_y_weights.device)
    for start in range(0, num_basis, chunk):
        end = min(start + chunk, num_basis)
        selected = basis_indices[start:end]
        y_index = selected // basis_x_weights.shape[1]
        x_index = selected % basis_x_weights.shape[1]
        basis_chunk = (
            basis_y_weights[:, y_index].T[:, :, None] * basis_x_weights[:, x_index].T[:, None, :]
        ).reshape(end - start, grid_size * grid_size)
        propagated = _linear_conv2d_fft(
            basis_chunk,
            domain_kernel_fft,
            grid_size,
            adjoint=False,
        )
        k_diag[start:end] = cell_area * torch.sum(propagated * basis_chunk, dim=1)
    return k_diag, mass_diag


def _project_sensor_matrix(dense_h: torch.Tensor, basis_weights: torch.Tensor) -> torch.Tensor:
    if dense_h.ndim == 3:
        return torch.einsum("trp,pb->trb", dense_h, basis_weights)
    return dense_h @ basis_weights


def _make_synthetic_lattice_basis(
    model: SyntheticScatteringModel, grid_size: int, sigma_scale: float
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Place Gaussian centers on a fixed row-major image lattice."""
    x_values = np.asarray(model.xx.reshape(model.ny, model.nx)[0].detach().cpu(), dtype=np.float64)
    y_values = np.asarray(
        model.yy.reshape(model.ny, model.nx)[:, 0].detach().cpu(), dtype=np.float64
    )
    x_lattice = np.linspace(float(x_values[0]), float(x_values[-1]), grid_size)
    y_lattice = np.linspace(float(y_values[0]), float(y_values[-1]), grid_size)
    row_idx = np.argmin(np.abs(y_values[:, None] - y_lattice[None, :]), axis=0)
    col_idx = np.argmin(np.abs(x_values[:, None] - x_lattice[None, :]), axis=0)
    rr, cc = np.meshgrid(row_idx, col_idx, indexing="ij")
    target_indices_np = (rr.reshape(-1) * model.nx + cc.reshape(-1)).astype(np.int64)
    xx_lattice, yy_lattice = np.meshgrid(x_lattice, y_lattice, indexing="xy")
    centers_np = np.stack([xx_lattice.reshape(-1), yy_lattice.reshape(-1)], axis=1)

    if grid_size > 1:
        sx = (
            float(torch.max(model.xx).detach().cpu()) - float(torch.min(model.xx).detach().cpu())
        ) / (grid_size - 1)
        sy = (
            float(torch.max(model.yy).detach().cpu()) - float(torch.min(model.yy).detach().cpu())
        ) / (grid_size - 1)
    else:
        sx = model.dx
        sy = model.dy
    sigma_np = np.empty_like(centers_np)
    sigma_np[:, 0] = sigma_scale * sx
    sigma_np[:, 1] = sigma_scale * sy
    source_area_np = np.full(centers_np.shape[0], sx * sy, dtype=np.float64)

    centers = torch.as_tensor(centers_np, device=model.device, dtype=model.real_dtype)
    sigma = torch.as_tensor(sigma_np, device=model.device, dtype=model.real_dtype)
    source_area = torch.as_tensor(source_area_np, device=model.device, dtype=model.real_dtype)
    target_indices = torch.as_tensor(target_indices_np, device=model.device, dtype=torch.long)
    return centers, sigma, source_area, target_indices


def _make_separable_basis_weights(
    model: SyntheticScatteringModel,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
    grid_size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Factor Gaussian projection into independent y- and x-axis weights."""
    center_grid = centers.reshape(grid_size, grid_size, 2)
    sigma_grid = sigma.reshape(grid_size, grid_size, 2)
    x_coords = model.xx.reshape(model.ny, model.nx)[0]
    y_coords = model.yy.reshape(model.ny, model.nx)[:, 0]
    x_centers = center_grid[0, :, 0]
    y_centers = center_grid[:, 0, 1]
    x_sigma = sigma_grid[0, :, 0]
    y_sigma = sigma_grid[:, 0, 1]
    sigma_tol = 1e-5 if model.real_dtype == torch.float32 else 1e-10
    if not (
        torch.allclose(sigma[:, 0], sigma[:1, 0].expand_as(sigma[:, 0]), atol=sigma_tol)
        and torch.allclose(sigma[:, 1], sigma[:1, 1].expand_as(sigma[:, 1]), atol=sigma_tol)
        and torch.allclose(source_area, source_area[:1].expand_as(source_area), atol=sigma_tol)
    ):
        raise ValueError("Separable projection requires uniform Gaussian scales and areas")

    raw_y = torch.exp(-0.5 * ((y_coords[:, None] - y_centers[None, :]) / y_sigma) ** 2)
    raw_x = torch.exp(-0.5 * ((x_coords[:, None] - x_centers[None, :]) / x_sigma) ** 2)
    norm = source_area[0] / (2.0 * torch.pi * sigma[0, 0] * sigma[0, 1])
    basis_y = raw_y
    basis_x = norm * raw_x
    render_y = raw_y / torch.clamp(torch.sum(raw_y, dim=1, keepdim=True), min=1e-12)
    render_x = raw_x / torch.clamp(torch.sum(raw_x, dim=1, keepdim=True), min=1e-12)
    return basis_y, basis_x, render_y, render_x


def _make_dense_basis_weights(
    model: SyntheticScatteringModel,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    points = model.pixel_points
    dx = (points[:, None, 0] - centers[None, :, 0]) / sigma[None, :, 0]
    dy = (points[:, None, 1] - centers[None, :, 1]) / sigma[None, :, 1]
    gaussian = torch.exp(-0.5 * (dx.square() + dy.square()))
    norm = source_area[None, :] / (2.0 * torch.pi * sigma[None, :, 0] * sigma[None, :, 1])
    basis_weights = norm * gaussian
    render = gaussian / torch.clamp(torch.sum(gaussian, dim=1, keepdim=True), min=1e-12)
    return basis_weights, render.T
