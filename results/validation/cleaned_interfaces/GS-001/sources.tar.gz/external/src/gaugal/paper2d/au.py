"""Load the bundled AU Ring inverse-scattering case."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from .synthetic import SyntheticScatteringModel


def load_au_case(
    source: str | Path,
    *,
    device: str | torch.device = "cuda",
    dtype: torch.dtype = torch.complex64,
    test_noise_ratio: float = 0.05,
    noise_seed: int = 1000,
) -> SyntheticScatteringModel:
    """Load the compact AU operators and add deterministic measurement noise."""
    if dtype not in (torch.complex64, torch.complex128):
        raise ValueError("dtype must be torch.complex64 or torch.complex128")
    if test_noise_ratio < 0.0:
        raise ValueError("test_noise_ratio must be non-negative")

    required = {
        "schema_version",
        "frequency_ghz",
        "epsilon",
        "x_dom",
        "y_dom",
        "data_clean",
        "uinc",
        "sensor_operator",
        "domain_kernel_pad",
        "transmitters",
        "receivers",
    }
    with np.load(Path(source), allow_pickle=False) as archive:
        missing = required.difference(archive.files)
        if missing:
            raise ValueError(f"AU archive is missing: {', '.join(sorted(missing))}")
        if int(archive["schema_version"]) != 1:
            raise ValueError("Unsupported AU archive schema")
        frequency_ghz = float(archive["frequency_ghz"])
        epsilon = np.asarray(archive["epsilon"])
        x_dom = np.asarray(archive["x_dom"])
        y_dom = np.asarray(archive["y_dom"])
        data_clean = np.asarray(archive["data_clean"])
        uinc = np.asarray(archive["uinc"])
        sensor_operator = np.asarray(archive["sensor_operator"])
        domain_kernel_pad = np.asarray(archive["domain_kernel_pad"])
        transmitters = np.asarray(archive["transmitters"])
        receivers = np.asarray(archive["receivers"])

    ny, nx = epsilon.shape
    if nx != ny or x_dom.shape != (ny, nx) or y_dom.shape != (ny, nx):
        raise ValueError("AU epsilon, x_dom, and y_dom must share one square grid")
    if data_clean.ndim != 2:
        raise ValueError("AU data_clean must have shape (N_tx, N_rx)")
    num_tx, num_rx = data_clean.shape
    if uinc.shape != (num_tx, nx * ny):
        raise ValueError("AU uinc shape is incompatible with the image grid")
    if sensor_operator.shape != (num_rx, nx * ny):
        raise ValueError("AU sensor operator shape is incompatible with the image grid")
    if domain_kernel_pad.shape != (2 * ny, 2 * nx):
        raise ValueError("AU domain kernel must have shape (2N, 2N)")
    if transmitters.shape != (num_tx, 2) or receivers.shape != (num_rx, 2):
        raise ValueError("AU transmitter or receiver coordinates have an invalid shape")
    if frequency_ghz <= 0.0:
        raise ValueError("AU frequency must be positive")

    device = torch.device(device)
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    data = _add_measurement_noise(data_clean, test_noise_ratio, noise_seed)
    x_unique = np.unique(x_dom)
    y_unique = np.unique(y_dom)
    dx = float(np.mean(np.abs(np.diff(x_unique))))
    dy = float(np.mean(np.abs(np.diff(y_unique))))
    length = float(max(np.ptp(x_unique), np.ptp(y_unique)))
    wavelength = 3.0e8 / (frequency_ghz * 1.0e9)

    xx = torch.as_tensor(x_dom, device=device, dtype=real_dtype)
    yy = torch.as_tensor(y_dom, device=device, dtype=real_dtype)
    empty = torch.empty((0, 0), device=device, dtype=dtype)
    kernel = torch.as_tensor(domain_kernel_pad, device=device, dtype=dtype)

    return SyntheticScatteringModel(
        file_name="AU Ring",
        frequency_ghz=frequency_ghz,
        wavelength=wavelength,
        kb=2.0 * np.pi / wavelength,
        length=length,
        nx=nx,
        ny=ny,
        dx=dx,
        dy=dy,
        x=torch.as_tensor(x_unique, device=device, dtype=real_dtype),
        y=torch.as_tensor(y_unique, device=device, dtype=real_dtype),
        xx=xx,
        yy=yy,
        data=torch.as_tensor(data, device=device, dtype=dtype),
        receiver_mask=torch.ones(data.shape, device=device, dtype=torch.bool),
        uinc=torch.as_tensor(uinc, device=device, dtype=dtype),
        nominal_truth=torch.as_tensor(epsilon - 1.0, device=device, dtype=real_dtype),
        dense_g=empty,
        dense_h=torch.as_tensor(sensor_operator, device=device, dtype=dtype),
        pixel_points=torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=1),
        x_transmit=torch.as_tensor(transmitters[:, 0], device=device, dtype=real_dtype),
        y_transmit=torch.as_tensor(transmitters[:, 1], device=device, dtype=real_dtype),
        x_receive=torch.as_tensor(receivers[:, 0], device=device, dtype=real_dtype),
        y_receive=torch.as_tensor(receivers[:, 1], device=device, dtype=real_dtype),
        domain_kernel_fft=torch.fft.fft2(kernel),
    )


def _add_measurement_noise(values: np.ndarray, noise_ratio: float, seed: int) -> np.ndarray:
    """Apply the paper's complex Gaussian noise convention in Tx-first order."""
    values = np.asarray(values, dtype=np.complex128)
    if noise_ratio <= 0.0:
        return values
    rng = np.random.RandomState(seed)
    scale = float(np.sqrt(np.mean(values.real**2 + values.imag**2)) / np.sqrt(2.0))
    return values + scale * noise_ratio * rng.randn(*values.shape) + 1j * (
        scale * noise_ratio * rng.randn(*values.shape)
    )
