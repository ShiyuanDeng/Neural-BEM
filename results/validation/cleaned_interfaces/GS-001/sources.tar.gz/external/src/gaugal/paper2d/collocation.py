"""Gaussian-lattice operators for the 2-D lumped Galerkin solver."""

from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter

import numpy as np
import torch
import torch.nn.functional as F

from .fresnel import FresnelModel
from .operators import batched_inner
from .solver import ReconstructionOptions
from .tv import denoise_tv


@dataclass
class CollocationOptions(ReconstructionOptions):
    """Operator and linear-solver settings for the Gaussian lattice."""

    collocation_form: str = "galerkin"
    collocation_linear_solver: str = "bicgstab"
    collocation_preconditioner: str = "auto"
    collocation_matvec_mode: str = "fft"
    collocation_fft_assembly: str = "kernel"
    collocation_grid_size: int = 48
    collocation_sigma_scale: float = 0.5
    collocation_quadrature_order: int = 6
    collocation_chunk_size: int = 64
    collocation_step_size: float = 1.0
    collocation_contrast_mode: str = "auto"
    collocation_tv_mode: str = "auto"
    collocation_gradient_preconditioner: str = "auto"
    collocation_external_operator: str = "dense"
    collocation_harmonic_order: int = 15
    collocation_harmonic_rcond: float = 1e-6
    collocation_variable_preconditioner_steps: int = 1
    collocation_variable_preconditioner_relaxation: float = 0.8
    collocation_variable_preconditioner_smoothing: int = 1
    collocation_bicgstab_mode: str = "sync"
    collocation_bicgstab_sync_every: int = 4
    collocation_bicgstab_fixed_iter: int = 8
    collocation_reuse_fft_workspace: bool = True
    collocation_profile: bool = False


@dataclass
class GaussianCollocationModel:
    """Projected fields/operators on one fixed Gaussian coefficient lattice."""

    centers: torch.Tensor
    sigma: torch.Tensor
    source_area: torch.Tensor
    basis_indices: torch.Tensor
    source_cell_area: float
    k_matrix: torch.Tensor
    r_matrix: torch.Tensor
    mass_matrix: torch.Tensor
    k_diag: torch.Tensor
    mass_diag: torch.Tensor
    mass_lump: torch.Tensor
    k_kernel_fft: torch.Tensor
    mass_kernel_fft: torch.Tensor
    uinc: torch.Tensor
    render_weights: torch.Tensor
    tv_scale: float
    grid_size: int
    form: str
    contrast_mode: str
    matvec_mode: str
    build_seconds: float
    basis_weights: torch.Tensor | None = None
    basis_y_weights: torch.Tensor | None = None
    basis_x_weights: torch.Tensor | None = None
    domain_kernel_fft: torch.Tensor | None = None
    domain_grid_size: int = 0
    domain_cell_area: float = 1.0
    render_y_weights: torch.Tensor | None = None
    render_x_weights: torch.Tensor | None = None
    separable_mass_y_inverse: torch.Tensor | None = None
    separable_mass_x_inverse: torch.Tensor | None = None
    r_harmonic_gamma: torch.Tensor | None = None
    r_harmonic_basis: torch.Tensor | None = None
    external_operator: str = "dense"
    external_fit_rel_error: float = float("nan")
    profile: bool = False
    linear_solve_stats: list[dict[str, float]] = field(default_factory=list)
    timing_stats: dict[str, float] = field(default_factory=dict)
    fft_workspace: dict[tuple[torch.dtype, tuple[int, ...], int], torch.Tensor] = field(
        default_factory=dict,
        repr=False,
    )
    reuse_fft_workspace: bool = False

    @property
    def device(self) -> torch.device:
        return self.centers.device

    @property
    def dtype(self) -> torch.dtype:
        if self.k_matrix.numel() != 0:
            return self.k_matrix.dtype
        if self.k_kernel_fft.numel() != 0:
            return self.k_kernel_fft.dtype
        return self.r_matrix.dtype

    @property
    def real_dtype(self) -> torch.dtype:
        return self.centers.dtype

    @property
    def num_basis(self) -> int:
        return self.centers.shape[0]


def build_gaussian_collocation_model(
    model: FresnelModel, opts: CollocationOptions
) -> GaussianCollocationModel:
    """Assemble the Galerkin-kernel model for a measured Fresnel target."""
    grid_size = opts.collocation_grid_size
    centers, sigma, source_area, _ = _make_lattice_basis(
        model, grid_size, opts.collocation_sigma_scale
    )
    return build_gaussian_collocation_model_from_basis(
        model,
        opts,
        centers,
        sigma,
        source_area,
        grid_size=grid_size,
        basis_indices_input=None,
    )


def build_gaussian_collocation_model_from_basis(
    model: FresnelModel,
    opts: CollocationOptions,
    centers_input: torch.Tensor | np.ndarray,
    sigma_input: torch.Tensor | np.ndarray,
    source_area_input: torch.Tensor | np.ndarray,
    *,
    grid_size: int,
    basis_indices_input: torch.Tensor | np.ndarray | None = None,
) -> GaussianCollocationModel:
    start = perf_counter()
    real_dtype = model.real_dtype
    complex_dtype = model.dtype
    device = model.device

    centers = torch.as_tensor(centers_input, device=device, dtype=real_dtype)
    sigma = torch.as_tensor(sigma_input, device=device, dtype=real_dtype)
    source_area = torch.as_tensor(source_area_input, device=device, dtype=real_dtype).reshape(-1)
    if basis_indices_input is None:
        if grid_size > 0 and centers.shape[0] == grid_size * grid_size:
            basis_indices = torch.arange(centers.shape[0], device=device, dtype=torch.long)
        else:
            basis_indices = torch.empty(0, device=device, dtype=torch.long)
    else:
        basis_indices = torch.as_tensor(basis_indices_input, device=device, dtype=torch.long)
    source_cell_area = float(torch.mean(source_area).detach().cpu())
    if opts.collocation_form not in {"collocation", "galerkin"}:
        raise ValueError(f"Unknown collocation form: {opts.collocation_form}")
    contrast_mode = _resolve_contrast_mode(opts)
    matvec_mode = _resolve_collocation_matvec_mode(opts, grid_size, basis_indices, centers.shape[0])
    build_linear_solver = _resolve_collocation_linear_solver_name(
        opts.collocation_form, centers.shape[0], opts
    )
    use_kernel_only_fft = _use_kernel_only_galerkin_fft(
        opts,
        matvec_mode,
        grid_size,
        basis_indices,
        centers,
        sigma,
        source_area,
        build_linear_solver,
    )
    empty_complex = torch.empty((0, 0), device=device, dtype=complex_dtype)
    k_kernel_fft = empty_complex
    mass_kernel_fft = empty_complex
    k_diag: torch.Tensor | None = None
    mass_diag: torch.Tensor | None = None

    receivers = torch.stack([model.x_receive, model.y_receive], dim=1)
    transmitters = torch.stack([model.x_transmit, model.y_transmit], dim=1)
    external_operator = _resolve_collocation_external_operator(opts)
    r_harmonic_gamma = None
    r_harmonic_basis = None
    external_fit_rel_error = float("nan")
    basis_y_weights = None
    basis_x_weights = None
    separable_mass_y_inverse = None
    separable_mass_x_inverse = None
    domain_cell_area = model.dx * model.dy
    if opts.collocation_form == "galerkin":
        if use_kernel_only_fft:
            k_matrix = empty_complex
            mass_matrix = empty_complex
            (
                k_kernel_fft,
                mass_kernel_fft,
                k_diag,
                mass_diag,
            ) = _build_lattice_galerkin_kernel_ffts(
                model,
                centers,
                sigma,
                source_area,
                grid_size,
                quadrature_order=opts.collocation_quadrature_order,
                chunk_size=opts.collocation_chunk_size,
            )
        else:
            k_matrix = _galerkin_green_matrix_torch(
                model,
                centers,
                centers,
                sigma,
                sigma,
                source_area,
                source_area,
                quadrature_order=opts.collocation_quadrature_order,
                chunk_size=opts.collocation_chunk_size,
            )
            mass_matrix = _gaussian_mass_matrix_torch(
                centers,
                sigma,
                source_area,
                dtype=complex_dtype,
                chunk_size=opts.collocation_chunk_size,
            )
        external = _integrated_green_matrix_torch(
            model,
            torch.cat([transmitters, receivers], dim=0),
            centers,
            sigma,
            source_area,
            quadrature_order=opts.collocation_quadrature_order,
            chunk_size=opts.collocation_chunk_size,
        )
        external_t = external[: transmitters.shape[0]]
        external_r = external[transmitters.shape[0] :]
        if external_operator == "harmonic":
            (
                gamma_all,
                harmonic_basis,
                external_fit_rel_error,
            ) = _harmonic_factorize_external(
                torch.cat([transmitters, receivers], dim=0),
                external,
                opts,
            )
            num_transmitters = transmitters.shape[0]
            gamma_t = gamma_all[:num_transmitters]
            r_harmonic_gamma = gamma_all[num_transmitters:]
            r_harmonic_basis = harmonic_basis
            external_t = gamma_t @ harmonic_basis
            external_r = torch.empty((0, 0), device=device, dtype=complex_dtype)
        uinc = model.amp / (model.kb * model.kb) * external_t
        r_matrix = external_r
    else:
        k_matrix = _integrated_green_matrix_torch(
            model,
            centers,
            centers,
            sigma,
            source_area,
            quadrature_order=opts.collocation_quadrature_order,
            chunk_size=opts.collocation_chunk_size,
        )
        mass_matrix = torch.empty((0, 0), device=device, dtype=complex_dtype)
        distance = torch.linalg.vector_norm(transmitters[:, None, :] - centers[None, :, :], dim=2)
        uinc = model.amp * _hankel_green_torch(model.kb * distance, complex_dtype)
        r_matrix = _integrated_green_matrix_torch(
            model,
            receivers,
            centers,
            sigma,
            source_area,
            quadrature_order=opts.collocation_quadrature_order,
            chunk_size=opts.collocation_chunk_size,
        )
        if external_operator == "harmonic":
            (
                r_harmonic_gamma,
                r_harmonic_basis,
                external_fit_rel_error,
            ) = _harmonic_factorize_external(receivers, r_matrix, opts)
            r_matrix = torch.empty((0, 0), device=device, dtype=complex_dtype)

    if k_diag is None:
        k_diag = torch.diagonal(k_matrix).clone()
    if mass_diag is None and mass_matrix.numel() == 0:
        mass_diag = torch.ones(centers.shape[0], device=device, dtype=complex_dtype)
    elif mass_diag is None:
        mass_diag = torch.diagonal(mass_matrix).clone()

    render_weights = _build_render_weights(model, centers, sigma)
    tv_scale = 1.0 / min(model.dx, model.dy)
    _synchronize_if_needed(device)

    collocation = GaussianCollocationModel(
        centers=centers,
        sigma=sigma,
        source_area=source_area,
        basis_indices=basis_indices,
        source_cell_area=source_cell_area,
        k_matrix=k_matrix,
        r_matrix=r_matrix,
        mass_matrix=mass_matrix,
        k_diag=k_diag,
        mass_diag=mass_diag,
        mass_lump=mass_diag.clone(),
        k_kernel_fft=k_kernel_fft,
        mass_kernel_fft=mass_kernel_fft,
        uinc=uinc,
        render_weights=render_weights,
        tv_scale=tv_scale,
        grid_size=grid_size,
        form=opts.collocation_form,
        contrast_mode=contrast_mode,
        matvec_mode=matvec_mode,
        build_seconds=perf_counter() - start,
        basis_y_weights=basis_y_weights,
        basis_x_weights=basis_x_weights,
        domain_cell_area=domain_cell_area,
        separable_mass_y_inverse=separable_mass_y_inverse,
        separable_mass_x_inverse=separable_mass_x_inverse,
        r_harmonic_gamma=r_harmonic_gamma,
        r_harmonic_basis=r_harmonic_basis,
        external_operator=external_operator,
        external_fit_rel_error=external_fit_rel_error,
        reuse_fft_workspace=opts.collocation_reuse_fft_workspace,
        profile=opts.collocation_profile,
    )
    collocation.mass_lump = _compute_mass_lump(collocation)
    return collocation


def _resolve_contrast_mode(opts: CollocationOptions) -> str:
    if opts.collocation_form != "galerkin" or opts.collocation_contrast_mode not in {
        "auto",
        "lumped-galerkin",
    }:
        raise ValueError("The public paper path supports only lumped Galerkin coupling")
    return "lumped-galerkin"


def _resolve_collocation_tv_mode(
    collocation: GaussianCollocationModel, opts: CollocationOptions
) -> str:
    valid_modes = {"auto", "coefficient", "rendered"}
    if opts.collocation_tv_mode not in valid_modes:
        raise ValueError(f"Unknown collocation TV mode: {opts.collocation_tv_mode}")
    if opts.collocation_tv_mode == "auto":
        return "coefficient"
    return opts.collocation_tv_mode


def _resolve_collocation_external_operator(opts: CollocationOptions) -> str:
    valid = {"dense", "harmonic"}
    if opts.collocation_external_operator not in valid:
        raise ValueError(
            f"Unknown collocation external operator: {opts.collocation_external_operator}"
        )
    if opts.collocation_harmonic_order < 0:
        raise ValueError("collocation_harmonic_order must be nonnegative")
    return opts.collocation_external_operator


def _resolve_collocation_gradient_preconditioner(
    collocation: GaussianCollocationModel, opts: CollocationOptions
) -> str:
    if opts.collocation_gradient_preconditioner not in {"auto", "none"}:
        raise ValueError("The public paper path does not use gradient preconditioning")
    return "none"


def _collocation_step_gradient(
    collocation: GaussianCollocationModel, grad: torch.Tensor, opts: CollocationOptions
) -> torch.Tensor:
    _resolve_collocation_gradient_preconditioner(collocation, opts)
    return grad


def collocation_gradient(
    model: FresnelModel,
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    u_warm: torch.Tensor,
    v_warm: torch.Tensor,
    opts: CollocationOptions,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Differentiate data misfit through forward and adjoint field solves.

    The coefficient gradient is real; field and sensor adjoints use complex
    conjugation. Warm starts reuse the previous forward and adjoint fields.
    """
    if _collocation_linear_solver(collocation, opts) == "direct":
        lu, pivots = _timed_phase(
            collocation,
            "direct_factor",
            lambda: torch.linalg.lu_factor(_dense_system_matrix(collocation, coeff)),
        )
        u = _timed_phase(
            collocation,
            "forward_solve",
            lambda: _direct_lu_solve(lu, pivots, collocation.uinc, adjoint=False),
        )
        data_pred = collocation_sensor_forward(model, collocation, coeff, u)
        res = data_pred - model.data
        p = collocation_sensor_adjoint(model, collocation, res)
        rhs_source = _timed_phase(
            collocation,
            "source_adjoint",
            lambda: _contrast_source_u_adjoint(collocation, coeff, p),
        )
        v = _timed_phase(
            collocation,
            "adjoint_solve",
            lambda: _direct_lu_solve(lu, pivots, rhs_source, adjoint=True),
        )
        kt_v = _timed_phase(collocation, "green_adjoint", lambda: _k_adjoint(collocation, v))
        grad = _timed_phase(
            collocation,
            "coeff_gradient",
            lambda: _contrast_source_coeff_adjoint(collocation, u, p + kt_v),
        )
        return grad, u, v, data_pred

    u = collocation_forward_prop(collocation, coeff, u_warm, opts)
    data_pred = collocation_sensor_forward(model, collocation, coeff, u)
    res = data_pred - model.data
    p = collocation_sensor_adjoint(model, collocation, res)
    rhs_source = _timed_phase(
        collocation,
        "source_adjoint",
        lambda: _contrast_source_u_adjoint(collocation, coeff, p),
    )
    v = collocation_backward_prop(collocation, coeff, rhs_source, v_warm, opts)
    kt_v = _timed_phase(collocation, "green_adjoint", lambda: _k_adjoint(collocation, v))
    grad = _timed_phase(
        collocation,
        "coeff_gradient",
        lambda: _contrast_source_coeff_adjoint(collocation, u, p + kt_v),
    )
    return grad, u, v, data_pred


def collocation_forward_prop(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    u0: torch.Tensor,
    opts: CollocationOptions,
) -> torch.Tensor:
    """Solve the lumped Galerkin field equation for each transmitter."""

    def solve() -> torch.Tensor:
        linear_solver = _collocation_linear_solver(collocation, opts)
        if linear_solver == "direct":
            return _direct_solve(collocation, coeff, collocation.uinc, adjoint=False)
        if linear_solver == "bicgstab":
            solution, info = _bicgstab(
                lambda x: collocation_a_forward(collocation, coeff, x),
                collocation.uinc,
                u0,
                tol=opts.pcg_tol,
                max_iter=opts.pcg_max_iter,
                preconditioner=_collocation_preconditioner(collocation, coeff, opts, adjoint=False),
                mode=opts.collocation_bicgstab_mode,
                sync_every=opts.collocation_bicgstab_sync_every,
                fixed_iter=opts.collocation_bicgstab_fixed_iter,
                return_info=True,
            )
            _record_linear_solve(collocation, "forward", info)
            return solution

        rhs = collocation_a_adjoint(collocation, coeff, collocation.uinc)
        return _pcg(
            lambda x: collocation_a_adjoint(
                collocation, coeff, collocation_a_forward(collocation, coeff, x)
            ),
            rhs,
            u0,
            tol=opts.pcg_tol,
            max_iter=opts.pcg_max_iter,
        )

    return _timed_phase(collocation, "forward_solve", solve)


def collocation_backward_prop(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    rhs_source: torch.Tensor,
    v0: torch.Tensor,
    opts: CollocationOptions,
) -> torch.Tensor:
    """Solve the adjoint field equation used by the data-misfit gradient."""

    def solve() -> torch.Tensor:
        linear_solver = _collocation_linear_solver(collocation, opts)
        if linear_solver == "direct":
            return _direct_solve(collocation, coeff, rhs_source, adjoint=True)
        if linear_solver == "bicgstab":
            solution, info = _bicgstab(
                lambda x: collocation_a_adjoint(collocation, coeff, x),
                rhs_source,
                v0,
                tol=opts.pcg_tol,
                max_iter=opts.pcg_max_iter,
                preconditioner=_collocation_preconditioner(collocation, coeff, opts, adjoint=True),
                mode=opts.collocation_bicgstab_mode,
                sync_every=opts.collocation_bicgstab_sync_every,
                fixed_iter=opts.collocation_bicgstab_fixed_iter,
                return_info=True,
            )
            _record_linear_solve(collocation, "adjoint", info)
            return solution

        rhs = collocation_a_forward(collocation, coeff, rhs_source)
        return _pcg(
            lambda x: collocation_a_forward(
                collocation, coeff, collocation_a_adjoint(collocation, coeff, x)
            ),
            rhs,
            v0,
            tol=opts.pcg_tol,
            max_iter=opts.pcg_max_iter,
        )

    return _timed_phase(collocation, "adjoint_solve", solve)


def _collocation_linear_solver(
    collocation: GaussianCollocationModel, opts: CollocationOptions
) -> str:
    return _resolve_collocation_linear_solver_name(collocation.form, collocation.num_basis, opts)


def _resolve_collocation_linear_solver_name(
    form: str, num_basis: int, opts: CollocationOptions
) -> str:
    if opts.collocation_linear_solver not in {"normal", "bicgstab", "direct"}:
        raise ValueError(f"Unknown collocation linear solver: {opts.collocation_linear_solver}")
    return opts.collocation_linear_solver


def _collocation_preconditioner_name(
    linear_solver: str,
    opts: CollocationOptions,
    collocation: GaussianCollocationModel | None = None,
) -> str:
    if linear_solver != "bicgstab":
        return "none"
    valid_preconditioners = {"auto", "none", "jacobi", "spectral", "variable-spectral"}
    if opts.collocation_preconditioner not in valid_preconditioners:
        raise ValueError(f"Unknown collocation preconditioner: {opts.collocation_preconditioner}")
    if opts.collocation_preconditioner == "auto" and collocation is not None:
        if _can_use_spectral_preconditioner(collocation):
            return "variable-spectral"
        return "jacobi"
    return opts.collocation_preconditioner


def _collocation_preconditioner(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    opts: CollocationOptions,
    *,
    adjoint: bool,
):
    preconditioner_name = _collocation_preconditioner_name("bicgstab", opts, collocation)
    if preconditioner_name == "none":
        return None
    if preconditioner_name == "spectral":
        return _spectral_collocation_preconditioner(
            collocation,
            coeff,
            adjoint=adjoint,
        )
    if preconditioner_name == "variable-spectral":
        return _variable_spectral_collocation_preconditioner(
            collocation,
            coeff,
            opts,
            adjoint=adjoint,
        )
    if preconditioner_name != "jacobi":
        raise ValueError(f"Unknown collocation preconditioner: {opts.collocation_preconditioner}")
    diag = _a_diagonal(collocation, coeff)
    if adjoint:
        diag = torch.conj(diag)
    return lambda residual: _safe_complex_div(residual, diag[None, :])


def _can_use_spectral_preconditioner(collocation: GaussianCollocationModel) -> bool:
    return (
        collocation.form == "galerkin"
        and collocation.contrast_mode == "lumped-galerkin"
        and collocation.matvec_mode == "fft"
        and collocation.k_kernel_fft.numel() != 0
        and _is_lattice_kernel_basis(
            collocation.grid_size,
            collocation.basis_indices,
            collocation.num_basis,
        )
    )


def _spectral_collocation_preconditioner(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    *,
    adjoint: bool,
):
    if not _can_use_spectral_preconditioner(collocation):
        raise ValueError("Spectral preconditioning requires a full-lattice Galerkin FFT operator")
    coeff_mean = torch.mean(coeff.to(collocation.real_dtype)).to(collocation.dtype)
    if collocation.mass_kernel_fft.numel() == 0:
        mass_symbol = torch.ones_like(collocation.k_kernel_fft)
    else:
        mass_symbol = collocation.mass_kernel_fft
    symbol = mass_symbol - coeff_mean * collocation.k_kernel_fft
    if adjoint:
        symbol = torch.conj(symbol)
    floor = _spectral_floor(symbol)

    def apply(residual: torch.Tensor) -> torch.Tensor:
        return _spectral_inverse_apply(collocation, residual, symbol, floor)

    return apply


def _variable_spectral_collocation_preconditioner(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    opts: CollocationOptions,
    *,
    adjoint: bool,
):
    if not _can_use_spectral_preconditioner(collocation):
        raise ValueError(
            "Variable spectral preconditioning requires a full-lattice lumped Galerkin FFT operator"
        )
    steps = int(opts.collocation_variable_preconditioner_steps)
    if steps < 0:
        raise ValueError("collocation_variable_preconditioner_steps must be nonnegative")
    relaxation = float(opts.collocation_variable_preconditioner_relaxation)
    if relaxation <= 0.0:
        raise ValueError("collocation_variable_preconditioner_relaxation must be positive")
    smoothing = int(opts.collocation_variable_preconditioner_smoothing)
    if smoothing < 0:
        raise ValueError("collocation_variable_preconditioner_smoothing must be nonnegative")

    coeff_smooth = _lowpass_lattice_coeff(collocation, coeff, smoothing)
    base_apply = _spectral_collocation_preconditioner(
        collocation,
        coeff_smooth,
        adjoint=adjoint,
    )
    operator = collocation_a_adjoint if adjoint else collocation_a_forward

    def apply(residual: torch.Tensor) -> torch.Tensor:
        estimate = base_apply(residual)
        for _ in range(steps):
            correction = residual - operator(collocation, coeff_smooth, estimate)
            estimate = estimate + relaxation * base_apply(correction)
        return estimate

    return apply


def _lowpass_lattice_coeff(
    collocation: GaussianCollocationModel, coeff: torch.Tensor, smoothing: int
) -> torch.Tensor:
    if smoothing <= 0:
        return coeff
    if not _is_lattice_kernel_basis(
        collocation.grid_size,
        collocation.basis_indices,
        collocation.num_basis,
    ):
        return coeff
    grid = coeff.reshape(1, 1, collocation.grid_size, collocation.grid_size)
    for _ in range(smoothing):
        grid = F.avg_pool2d(
            F.pad(grid, (1, 1, 1, 1), mode="replicate"),
            kernel_size=3,
            stride=1,
        )
    return grid.reshape_as(coeff)


def _spectral_inverse_apply(
    collocation: GaussianCollocationModel,
    residual: torch.Tensor,
    symbol: torch.Tensor,
    floor: torch.Tensor,
) -> torch.Tensor:
    residual_full = _lattice_basis_scatter(collocation, residual)
    spatial = residual_full.reshape(
        *residual_full.shape[:-1],
        collocation.grid_size,
        collocation.grid_size,
    )
    padded = (
        _fft_workspace(
            collocation,
            residual_full.dtype,
            residual_full.device,
            spatial.shape[:-2],
            collocation.grid_size,
        )
        if collocation.reuse_fft_workspace
        else torch.zeros(
            *spatial.shape[:-2],
            2 * collocation.grid_size,
            2 * collocation.grid_size,
            device=residual_full.device,
            dtype=residual_full.dtype,
        )
    )
    if collocation.reuse_fft_workspace:
        padded.zero_()
    padded[..., : collocation.grid_size, : collocation.grid_size] = spatial
    solved = _safe_complex_div_with_floor(torch.fft.fft2(padded), symbol, floor)
    out = torch.fft.ifft2(solved)
    out_full = out[..., : collocation.grid_size, : collocation.grid_size].reshape_as(residual_full)
    return _lattice_basis_gather(collocation, out_full, like=residual)


def _spectral_floor(symbol: torch.Tensor) -> torch.Tensor:
    rel_floor = 1e-6 if symbol.dtype in {torch.complex64, torch.float32} else 1e-12
    max_abs_sq = torch.max(torch.abs(symbol).square()).detach()
    return torch.clamp(max_abs_sq * rel_floor, min=1e-30)


def _safe_complex_div_with_floor(
    num: torch.Tensor, den: torch.Tensor, floor: torch.Tensor
) -> torch.Tensor:
    scale = torch.clamp(torch.abs(den).square(), min=floor)
    return num * torch.conj(den) / scale


def _reset_linear_stats(collocation: GaussianCollocationModel) -> None:
    collocation.linear_solve_stats.clear()


def _reset_timing_stats(collocation: GaussianCollocationModel) -> None:
    collocation.timing_stats.clear()


def _record_linear_solve(
    collocation: GaussianCollocationModel, phase: str, info: dict[str, float]
) -> None:
    collocation.linear_solve_stats.append({"phase": phase, **info})


def _add_timing_stat(collocation: GaussianCollocationModel, name: str, seconds: float) -> None:
    key = f"time_{name}_sec"
    collocation.timing_stats[key] = collocation.timing_stats.get(key, 0.0) + float(seconds)


def _timed_phase(collocation: GaussianCollocationModel, name: str, fn):
    if not collocation.profile:
        return fn()
    _synchronize_if_needed(collocation.device)
    start = perf_counter()
    result = fn()
    _synchronize_if_needed(collocation.device)
    _add_timing_stat(collocation, name, perf_counter() - start)
    return result


def _linear_stats_metrics(collocation: GaussianCollocationModel) -> dict[str, float]:
    stats = collocation.linear_solve_stats
    if not stats:
        return {
            "linear_solves": 0.0,
            "linear_iterations": 0.0,
            "linear_avg_iterations": 0.0,
            "linear_max_iterations": 0.0,
            "linear_final_rel": 0.0,
            "linear_not_converged": 0.0,
        }
    iterations = [entry["iterations"] for entry in stats]
    final_rel = [entry["final_rel"] for entry in stats]
    not_converged = [1.0 - entry["converged"] for entry in stats]
    return {
        "linear_solves": float(len(stats)),
        "linear_iterations": float(sum(iterations)),
        "linear_avg_iterations": float(sum(iterations) / len(iterations)),
        "linear_max_iterations": float(max(iterations)),
        "linear_final_rel": float(max(final_rel)),
        "linear_not_converged": float(sum(not_converged)),
    }


def _a_diagonal(collocation: GaussianCollocationModel, coeff: torch.Tensor) -> torch.Tensor:
    return collocation.mass_diag - collocation.k_diag * coeff.to(collocation.dtype)


def _operator_storage(collocation: GaussianCollocationModel) -> str:
    if collocation.k_matrix.numel() == 0 and (
        collocation.k_kernel_fft.numel() != 0 or _has_domain_kernel_operator(collocation)
    ):
        return "kernel"
    return "dense"


def _dense_system_matrix(
    collocation: GaussianCollocationModel, coeff: torch.Tensor
) -> torch.Tensor:
    if collocation.k_matrix.numel() == 0:
        raise ValueError("Direct dense solves require dense Galerkin matrices")
    if collocation.mass_matrix.numel() == 0:
        system = torch.mul(collocation.k_matrix, coeff[None, :]).neg()
        system.diagonal().add_(1.0)
        return system
    system = collocation.mass_matrix.clone()
    system.addcmul_(collocation.k_matrix, coeff[None, :], value=-1.0)
    return system


def _direct_solve(
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    rhs: torch.Tensor,
    *,
    adjoint: bool,
) -> torch.Tensor:
    lu, pivots = torch.linalg.lu_factor(_dense_system_matrix(collocation, coeff))
    return _direct_lu_solve(lu, pivots, rhs, adjoint=adjoint)


def _direct_lu_solve(
    lu: torch.Tensor,
    pivots: torch.Tensor,
    rhs: torch.Tensor,
    *,
    adjoint: bool,
) -> torch.Tensor:
    return torch.linalg.lu_solve(lu, pivots, rhs.T.contiguous(), adjoint=adjoint).T


def collocation_a_forward(
    collocation: GaussianCollocationModel, coeff: torch.Tensor, u: torch.Tensor
) -> torch.Tensor:
    """Apply A(a)u = Mu - K(a * u) without forming A densely."""
    return _mass_forward(collocation, u) - _k_forward(
        collocation, _contrast_source_forward(collocation, coeff, u)
    )


def collocation_a_adjoint(
    collocation: GaussianCollocationModel, coeff: torch.Tensor, z: torch.Tensor
) -> torch.Tensor:
    """Apply the complex adjoint of the lumped Galerkin field operator."""
    return _mass_adjoint(collocation, z) - _contrast_source_u_adjoint(
        collocation, coeff, _k_adjoint(collocation, z)
    )


def _k_forward(collocation: GaussianCollocationModel, source: torch.Tensor) -> torch.Tensor:
    if _has_domain_kernel_operator(collocation):
        return _domain_projected_k(collocation, source, adjoint=False)
    if collocation.k_kernel_fft.numel() == 0 and collocation.k_matrix.numel() != 0:
        return source @ collocation.k_matrix.T
    if collocation.k_kernel_fft.numel() == 0:
        raise ValueError("No Galerkin Green operator is available")
    return _lattice_basis_conv2d_fft(
        collocation,
        source,
        collocation.k_kernel_fft,
        adjoint=False,
    )


def _k_adjoint(collocation: GaussianCollocationModel, z: torch.Tensor) -> torch.Tensor:
    if _has_domain_kernel_operator(collocation):
        return _domain_projected_k(collocation, z, adjoint=True)
    if collocation.k_kernel_fft.numel() == 0 and collocation.k_matrix.numel() != 0:
        return z @ torch.conj(collocation.k_matrix)
    if collocation.k_kernel_fft.numel() == 0:
        raise ValueError("No Galerkin Green operator is available")
    return _lattice_basis_conv2d_fft(
        collocation,
        z,
        collocation.k_kernel_fft,
        adjoint=True,
    )


def _mass_forward(collocation: GaussianCollocationModel, u: torch.Tensor) -> torch.Tensor:
    if _has_domain_kernel_operator(collocation):
        return _domain_projected_mass(collocation, u)
    if collocation.mass_kernel_fft.numel() != 0:
        return _lattice_basis_conv2d_fft(
            collocation,
            u,
            collocation.mass_kernel_fft,
            adjoint=False,
        )
    if collocation.mass_matrix.numel() == 0:
        return u
    return u @ collocation.mass_matrix.T


def _mass_adjoint(collocation: GaussianCollocationModel, z: torch.Tensor) -> torch.Tensor:
    if _has_domain_kernel_operator(collocation):
        return _domain_projected_mass(collocation, z)
    if collocation.mass_kernel_fft.numel() != 0:
        return _lattice_basis_conv2d_fft(
            collocation,
            z,
            collocation.mass_kernel_fft,
            adjoint=True,
        )
    if collocation.mass_matrix.numel() == 0:
        return z
    return z @ torch.conj(collocation.mass_matrix)


def _compute_mass_lump(collocation: GaussianCollocationModel) -> torch.Tensor:
    ones = torch.ones(
        (1, collocation.num_basis),
        device=collocation.device,
        dtype=collocation.dtype,
    )
    return _mass_forward(collocation, ones).reshape(-1)


def _contrast_source_forward(
    collocation: GaussianCollocationModel, coeff: torch.Tensor, u: torch.Tensor
) -> torch.Tensor:
    """Multiply material and field coefficients elementwise."""
    return coeff[None, :] * u


def _contrast_source_u_adjoint(
    collocation: GaussianCollocationModel, coeff: torch.Tensor, w: torch.Tensor
) -> torch.Tensor:
    return coeff[None, :] * w


def _contrast_source_coeff_adjoint(
    collocation: GaussianCollocationModel, u: torch.Tensor, w: torch.Tensor
) -> torch.Tensor:
    return torch.sum(torch.real(torch.conj(u) * w), dim=0)


def _has_domain_kernel_operator(collocation: GaussianCollocationModel) -> bool:
    return (
        collocation.domain_kernel_fft is not None
        and collocation.domain_kernel_fft.numel() != 0
        and (
            (collocation.basis_weights is not None and collocation.basis_weights.numel() != 0)
            or _has_separable_basis(collocation)
        )
    )


def _has_separable_basis(collocation: GaussianCollocationModel) -> bool:
    return (
        collocation.basis_y_weights is not None
        and collocation.basis_x_weights is not None
        and collocation.basis_y_weights.numel() != 0
        and collocation.basis_x_weights.numel() != 0
    )


def _has_separable_render(collocation: GaussianCollocationModel) -> bool:
    return (
        collocation.render_y_weights is not None
        and collocation.render_x_weights is not None
        and collocation.render_y_weights.numel() != 0
        and collocation.render_x_weights.numel() != 0
    )


def _domain_projected_k(
    collocation: GaussianCollocationModel,
    source: torch.Tensor,
    *,
    adjoint: bool,
) -> torch.Tensor:
    source_pixels = _basis_coeff_to_pixels(collocation, source)
    propagated = _linear_conv2d_fft(
        source_pixels,
        collocation.domain_kernel_fft,
        collocation.domain_grid_size,
        adjoint=adjoint,
    )
    return collocation.domain_cell_area * _basis_pixels_to_coeff(collocation, propagated)


def _domain_projected_mass(
    collocation: GaussianCollocationModel, source: torch.Tensor
) -> torch.Tensor:
    source_pixels = _basis_coeff_to_pixels(collocation, source)
    return collocation.domain_cell_area * _basis_pixels_to_coeff(collocation, source_pixels)


def _basis_coeff_to_pixels(
    collocation: GaussianCollocationModel, coeff: torch.Tensor
) -> torch.Tensor:
    if _has_separable_basis(collocation):
        assert collocation.basis_y_weights is not None
        assert collocation.basis_x_weights is not None
        return _separable_coeff_to_pixels(
            coeff,
            collocation.basis_y_weights,
            collocation.basis_x_weights,
        )
    weights = collocation.basis_weights
    assert weights is not None
    return coeff @ weights.T


def _basis_pixels_to_coeff(
    collocation: GaussianCollocationModel, pixels: torch.Tensor
) -> torch.Tensor:
    if _has_separable_basis(collocation):
        assert collocation.basis_y_weights is not None
        assert collocation.basis_x_weights is not None
        return _separable_pixels_to_coeff(
            pixels,
            collocation.basis_y_weights,
            collocation.basis_x_weights,
        )
    weights = collocation.basis_weights
    assert weights is not None
    return pixels @ weights


def _separable_coeff_to_pixels(
    coeff: torch.Tensor,
    y_weights: torch.Tensor,
    x_weights: torch.Tensor,
) -> torch.Tensor:
    y = _basis_weight_to_dtype(y_weights, coeff.dtype)
    x = _basis_weight_to_dtype(x_weights, coeff.dtype)
    leading_shape = coeff.shape[:-1]
    coeff_grid = coeff.reshape(-1, y.shape[1], x.shape[1])
    pixels = torch.matmul(y, coeff_grid)
    pixels = torch.matmul(pixels, x.T)
    return pixels.reshape(*leading_shape, y.shape[0] * x.shape[0])


def _separable_pixels_to_coeff(
    pixels: torch.Tensor,
    y_weights: torch.Tensor,
    x_weights: torch.Tensor,
) -> torch.Tensor:
    y = _basis_weight_to_dtype(y_weights, pixels.dtype)
    x = _basis_weight_to_dtype(x_weights, pixels.dtype)
    leading_shape = pixels.shape[:-1]
    pixel_grid = pixels.reshape(-1, y.shape[0], x.shape[0])
    coeff_grid = torch.matmul(y.T, pixel_grid)
    coeff_grid = torch.matmul(coeff_grid, x)
    return coeff_grid.reshape(*leading_shape, y.shape[1] * x.shape[1])


def _separable_pixels_to_coeff_least_squares(
    pixels: torch.Tensor,
    y_weights: torch.Tensor,
    x_weights: torch.Tensor,
) -> torch.Tensor:
    y = _basis_weight_to_dtype(y_weights, pixels.dtype)
    x = _basis_weight_to_dtype(x_weights, pixels.dtype)
    pixel_grid = pixels.reshape(y.shape[0], x.shape[0])
    gram_y = _regularize_gram(y.T @ y)
    gram_x = _regularize_gram(x.T @ x)
    rhs = y.T @ pixel_grid @ x
    tmp = torch.linalg.solve(gram_y, rhs)
    coeff_grid = torch.linalg.solve(gram_x.T, tmp.T).T
    return torch.real(coeff_grid)


def _regularize_gram(gram: torch.Tensor) -> torch.Tensor:
    diag_mean = torch.mean(torch.real(torch.diagonal(gram))).clamp_min(1e-12)
    ridge = (1e-6 * diag_mean).to(dtype=gram.dtype)
    eye = torch.eye(gram.shape[0], device=gram.device, dtype=gram.dtype)
    return gram + ridge * eye


def _basis_weight_to_dtype(weights: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
    if not torch.is_complex(torch.empty((), dtype=dtype, device=weights.device)):
        weights = torch.real(weights) if torch.is_complex(weights) else weights
    return weights.to(dtype=dtype)


def collocation_sensor_forward(
    model: FresnelModel,
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    u: torch.Tensor,
) -> torch.Tensor:
    def apply() -> torch.Tensor:
        source = _contrast_source_forward(collocation, coeff, u)
        if _has_harmonic_sensor_operator(collocation):
            assert collocation.r_harmonic_basis is not None
            assert collocation.r_harmonic_gamma is not None
            pred = (source @ collocation.r_harmonic_basis.T) @ collocation.r_harmonic_gamma.T
            return pred * model.receiver_mask.to(pred.dtype)
        if collocation.r_matrix.ndim == 3:
            pred = torch.einsum("tb,trb->tr", source, collocation.r_matrix)
        else:
            pred = source @ collocation.r_matrix.T
        return pred * model.receiver_mask.to(pred.dtype)

    return _timed_phase(collocation, "sensor_forward", apply)


def collocation_sensor_adjoint(
    model: FresnelModel, collocation: GaussianCollocationModel, z: torch.Tensor
) -> torch.Tensor:
    def apply() -> torch.Tensor:
        masked = z * model.receiver_mask.to(z.dtype)
        if _has_harmonic_sensor_operator(collocation):
            assert collocation.r_harmonic_basis is not None
            assert collocation.r_harmonic_gamma is not None
            harmonic_coeff = masked @ torch.conj(collocation.r_harmonic_gamma)
            return harmonic_coeff @ torch.conj(collocation.r_harmonic_basis)
        if collocation.r_matrix.ndim == 3:
            return torch.einsum("tr,trb->tb", masked, torch.conj(collocation.r_matrix))
        return masked @ torch.conj(collocation.r_matrix)

    return _timed_phase(collocation, "sensor_adjoint", apply)


def _has_harmonic_sensor_operator(collocation: GaussianCollocationModel) -> bool:
    return (
        collocation.r_harmonic_gamma is not None
        and collocation.r_harmonic_basis is not None
        and collocation.r_harmonic_gamma.numel() != 0
        and collocation.r_harmonic_basis.numel() != 0
    )


def render_collocation_contrast(
    model: FresnelModel, collocation: GaussianCollocationModel, coeff: torch.Tensor
) -> torch.Tensor:
    def apply() -> torch.Tensor:
        if _has_separable_render(collocation):
            assert collocation.render_y_weights is not None
            assert collocation.render_x_weights is not None
            recon_flat = _separable_coeff_to_pixels(
                coeff,
                collocation.render_y_weights,
                collocation.render_x_weights,
            )
            return recon_flat.reshape(model.ny, model.nx)
        recon_flat = coeff @ collocation.render_weights
        return recon_flat.reshape(model.ny, model.nx)

    return _timed_phase(collocation, "render", apply)


def _collocation_tv_prox(
    model: FresnelModel,
    collocation: GaussianCollocationModel,
    coeff_candidate: torch.Tensor,
    lam_step: float,
    tv_p0: torch.Tensor | None,
    tv_q0: torch.Tensor | None,
    opts: CollocationOptions,
    *,
    max_iter: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    def apply() -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
        tv_mode = _resolve_collocation_tv_mode(collocation, opts)
        if tv_mode == "coefficient":
            return _coefficient_tv_prox(
                collocation,
                coeff_candidate,
                lam_step,
                tv_p0,
                tv_q0,
                opts,
                max_iter=max_iter,
            )
        if tv_mode != "rendered":
            raise ValueError(f"Unknown collocation TV mode: {tv_mode}")

        image_candidate = render_collocation_contrast(model, collocation, coeff_candidate)
        image_next, next_p0, next_q0, iter_count = denoise_tv(
            image_candidate,
            lam_step,
            p0=tv_p0,
            q0=tv_q0,
            max_iter=opts.tv_max_iter if max_iter is None else max_iter,
            tol=opts.tv_tol,
            lower_bound=0.0,
            upper_bound=opts.contrast_max,
        )
        coeff_next = _render_pixels_to_coeff(model, collocation, image_next)
        coeff_next = torch.clamp(coeff_next, min=0.0, max=opts.contrast_max)
        return coeff_next.to(collocation.real_dtype), next_p0, next_q0, iter_count

    return _timed_phase(collocation, "tv_prox", apply)


def _coefficient_tv_prox(
    collocation: GaussianCollocationModel,
    coeff_candidate: torch.Tensor,
    lam_step: float,
    tv_p0: torch.Tensor | None,
    tv_q0: torch.Tensor | None,
    opts: CollocationOptions,
    *,
    max_iter: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Apply bounded isotropic TV directly to the Gaussian coefficients."""
    coeff_grid_input = coeff_candidate.reshape(collocation.grid_size, collocation.grid_size)

    coeff_grid, tv_p0, tv_q0, iter_count = denoise_tv(
        coeff_grid_input,
        lam_step,
        p0=tv_p0,
        q0=tv_q0,
        max_iter=opts.tv_max_iter if max_iter is None else max_iter,
        tol=opts.tv_tol,
        lower_bound=0.0,
        upper_bound=opts.contrast_max,
    )
    return coeff_grid.reshape(-1), tv_p0, tv_q0, iter_count


def _render_pixels_to_coeff(
    model: FresnelModel, collocation: GaussianCollocationModel, pixels: torch.Tensor
) -> torch.Tensor:
    if _has_separable_render(collocation):
        assert collocation.render_y_weights is not None
        assert collocation.render_x_weights is not None
        coeff = _separable_pixels_to_coeff_least_squares(
            pixels.reshape(model.ny, model.nx),
            collocation.render_y_weights,
            collocation.render_x_weights,
        )
        return coeff.reshape(-1).to(collocation.real_dtype)

    weights = collocation.render_weights
    pixel_flat = pixels.reshape(-1).to(weights.dtype)
    gram = weights @ weights.T
    rhs = weights @ pixel_flat
    gram = _regularize_gram(gram)
    coeff = torch.linalg.solve(gram, rhs)
    return torch.real(coeff).to(collocation.real_dtype)


def _resolve_collocation_matvec_mode(
    opts: CollocationOptions,
    grid_size: int,
    basis_indices: torch.Tensor,
    num_basis: int,
) -> str:
    if opts.collocation_matvec_mode not in {"dense", "fft"}:
        raise ValueError(f"Unknown collocation matvec mode: {opts.collocation_matvec_mode}")
    lattice_basis = _is_lattice_kernel_basis(grid_size, basis_indices, num_basis)
    can_fft = opts.collocation_form == "galerkin" and lattice_basis
    if opts.collocation_matvec_mode == "fft":
        if not can_fft:
            raise ValueError("FFT Galerkin matvecs require a fixed full Gaussian lattice")
        return "fft"
    return "dense"


def _is_lattice_kernel_basis(grid_size: int, basis_indices: torch.Tensor, num_basis: int) -> bool:
    if grid_size <= 0 or num_basis <= 0 or basis_indices.numel() != num_basis:
        return False
    if int(torch.min(basis_indices).detach().cpu()) < 0:
        return False
    if int(torch.max(basis_indices).detach().cpu()) >= grid_size * grid_size:
        return False
    if basis_indices.numel() <= 1:
        return True
    return bool(torch.all(basis_indices[1:] > basis_indices[:-1]).detach().cpu())


def _use_kernel_only_galerkin_fft(
    opts: CollocationOptions,
    matvec_mode: str,
    grid_size: int,
    basis_indices: torch.Tensor,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
    linear_solver: str,
) -> bool:
    if opts.collocation_fft_assembly not in {"dense", "kernel"}:
        raise ValueError(f"Unknown FFT assembly mode: {opts.collocation_fft_assembly}")
    if opts.collocation_fft_assembly == "dense":
        return False
    if matvec_mode != "fft" or opts.collocation_form != "galerkin":
        raise ValueError("Kernel-only FFT assembly requires Galerkin FFT matvec mode")
    if linear_solver == "direct":
        raise ValueError("Kernel-only FFT assembly cannot be used with direct dense solves")
    if not _is_lattice_kernel_basis(grid_size, basis_indices, centers.shape[0]):
        raise ValueError("Kernel-only FFT assembly requires fixed Gaussian lattice indices")
    if not _basis_centers_match_lattice_indices(centers, source_area, grid_size, basis_indices):
        raise ValueError("Kernel-only FFT assembly requires on-lattice Gaussian centers")
    if not _has_uniform_lattice_parameters(sigma, source_area):
        raise ValueError("Kernel-only FFT assembly requires uniform Gaussian scales and areas")
    return True


def _basis_centers_match_lattice_indices(
    centers: torch.Tensor,
    source_area: torch.Tensor,
    grid_size: int,
    basis_indices: torch.Tensor,
) -> bool:
    if centers.shape[0] != basis_indices.numel() or centers.numel() == 0:
        return False
    spacing = torch.sqrt(torch.mean(source_area))
    iy = torch.div(basis_indices, grid_size, rounding_mode="floor").to(centers.dtype)
    ix = torch.remainder(basis_indices, grid_size).to(centers.dtype)
    expected = torch.stack(
        [
            (iy - grid_size / 2) * spacing,
            (ix - grid_size / 2) * spacing,
        ],
        dim=1,
    )
    tol = 1e-5 if centers.dtype == torch.float32 else 1e-10
    return bool(torch.allclose(centers, expected, rtol=tol, atol=tol))


def _has_uniform_lattice_parameters(sigma: torch.Tensor, source_area: torch.Tensor) -> bool:
    sigma0 = sigma[:1]
    area0 = source_area[:1]
    sigma_tol = 1e-5 if sigma.dtype == torch.float32 else 1e-10
    area_tol = 1e-5 if source_area.dtype == torch.float32 else 1e-10
    return bool(
        torch.allclose(sigma, sigma0.expand_as(sigma), rtol=sigma_tol, atol=sigma_tol)
        and torch.allclose(
            source_area,
            area0.expand_as(source_area),
            rtol=area_tol,
            atol=area_tol,
        )
    )


def _matrix_to_lattice_kernel_fft(matrix: torch.Tensor, grid_size: int) -> torch.Tensor:
    padded_size = 2 * grid_size
    kernel_pad = torch.zeros(
        (padded_size, padded_size),
        device=matrix.device,
        dtype=matrix.dtype,
    )
    for dy in range(-(grid_size - 1), grid_size):
        iy = max(dy, 0)
        jy = iy - dy
        for dx in range(-(grid_size - 1), grid_size):
            ix = max(dx, 0)
            jx = ix - dx
            row = iy * grid_size + ix
            col = jy * grid_size + jx
            kernel_pad[dy % padded_size, dx % padded_size] = matrix[row, col]
    return torch.fft.fft2(kernel_pad)


def _linear_conv2d_fft(
    x: torch.Tensor,
    kernel_fft: torch.Tensor,
    grid_size: int,
    *,
    adjoint: bool,
) -> torch.Tensor:
    """Apply a zero-padded linear convolution or its Hermitian adjoint."""
    spatial = x.reshape(*x.shape[:-1], grid_size, grid_size)
    padded = torch.zeros(
        *spatial.shape[:-2],
        2 * grid_size,
        2 * grid_size,
        device=x.device,
        dtype=x.dtype,
    )
    padded[..., :grid_size, :grid_size] = spatial
    kernel = torch.conj(kernel_fft) if adjoint else kernel_fft
    out = torch.fft.ifft2(torch.fft.fft2(padded) * kernel)
    return out[..., :grid_size, :grid_size].reshape_as(x)


def _linear_conv2d_fft_cached(
    collocation: GaussianCollocationModel,
    x: torch.Tensor,
    kernel_fft: torch.Tensor,
    grid_size: int,
    *,
    adjoint: bool,
) -> torch.Tensor:
    spatial = x.reshape(*x.shape[:-1], grid_size, grid_size)
    padded = _fft_workspace(collocation, x.dtype, x.device, spatial.shape[:-2], grid_size)
    padded.zero_()
    padded[..., :grid_size, :grid_size].copy_(spatial)
    kernel = torch.conj(kernel_fft) if adjoint else kernel_fft
    out = torch.fft.ifft2(torch.fft.fft2(padded) * kernel)
    return out[..., :grid_size, :grid_size].reshape_as(x)


def _fft_workspace(
    collocation: GaussianCollocationModel,
    dtype: torch.dtype,
    device: torch.device,
    leading_shape: torch.Size | tuple[int, ...],
    grid_size: int,
) -> torch.Tensor:
    leading = tuple(int(dim) for dim in leading_shape)
    key = (dtype, leading, int(grid_size))
    padded_shape = (*leading, 2 * grid_size, 2 * grid_size)
    padded = collocation.fft_workspace.get(key)
    if padded is None or padded.shape != padded_shape or padded.device != device:
        padded = torch.empty(padded_shape, device=device, dtype=dtype)
        collocation.fft_workspace[key] = padded
    return padded


def _lattice_basis_conv2d_fft(
    collocation: GaussianCollocationModel,
    x: torch.Tensor,
    kernel_fft: torch.Tensor,
    *,
    adjoint: bool,
) -> torch.Tensor:
    x_full = _lattice_basis_scatter(collocation, x)
    if collocation.reuse_fft_workspace:
        y_full = _linear_conv2d_fft_cached(
            collocation,
            x_full,
            kernel_fft,
            collocation.grid_size,
            adjoint=adjoint,
        )
    else:
        y_full = _linear_conv2d_fft(
            x_full,
            kernel_fft,
            collocation.grid_size,
            adjoint=adjoint,
        )
    return _lattice_basis_gather(collocation, y_full, like=x)


def _lattice_basis_scatter(collocation: GaussianCollocationModel, x: torch.Tensor) -> torch.Tensor:
    grid_numel = collocation.grid_size * collocation.grid_size
    if x.shape[-1] == grid_numel:
        return x
    if collocation.basis_indices.numel() != x.shape[-1]:
        raise ValueError("Lattice FFT matvec requires active lattice basis indices")
    leading_shape = x.shape[:-1]
    x_flat = x.reshape(-1, x.shape[-1])
    full = torch.zeros(
        x_flat.shape[0],
        grid_numel,
        device=x.device,
        dtype=x.dtype,
    )
    full[:, collocation.basis_indices] = x_flat
    return full.reshape(*leading_shape, grid_numel)


def _lattice_basis_gather(
    collocation: GaussianCollocationModel,
    x_full: torch.Tensor,
    *,
    like: torch.Tensor,
) -> torch.Tensor:
    grid_numel = collocation.grid_size * collocation.grid_size
    if like.shape[-1] == grid_numel:
        return x_full.reshape_as(like)
    x_flat = x_full.reshape(-1, grid_numel)
    gathered = x_flat[:, collocation.basis_indices]
    return gathered.reshape_as(like)


def _pcg(operator, b: torch.Tensor, x0: torch.Tensor, *, tol: float, max_iter: int) -> torch.Tensor:
    x = x0.clone()
    r = b - operator(x)
    p = r.clone()
    rs_old = torch.real(batched_inner(r, r))
    b_norm = torch.sqrt(torch.clamp(torch.real(batched_inner(b, b)), min=1e-30))

    for _ in range(max_iter):
        ap = operator(p)
        denom = batched_inner(p, ap)
        alpha = rs_old / torch.clamp(torch.real(denom), min=1e-30)
        x = x + alpha[:, None] * p
        r = r - alpha[:, None] * ap
        rs_new = torch.real(batched_inner(r, r))
        rel = torch.sqrt(torch.clamp(rs_new, min=0.0)) / torch.clamp(b_norm, min=1e-15)
        if bool(torch.max(rel).detach().cpu() < tol):
            break
        beta = rs_new / torch.clamp(rs_old, min=1e-30)
        p = r + beta[:, None] * p
        rs_old = rs_new
    return x


def _bicgstab(
    operator,
    b: torch.Tensor,
    x0: torch.Tensor,
    *,
    tol: float,
    max_iter: int,
    preconditioner=None,
    mode: str = "sync",
    sync_every: int = 1,
    fixed_iter: int = 8,
    return_info: bool = False,
) -> torch.Tensor | tuple[torch.Tensor, dict[str, float]]:
    """Batched complex BiCGSTAB with warm starts and optional preconditioning."""
    if mode not in {"sync", "chunked", "fixed"}:
        raise ValueError(f"Unknown BiCGSTAB mode: {mode}")
    sync_every = max(1, int(sync_every))
    fixed_iter = max(1, min(int(fixed_iter), int(max_iter)))
    x = x0.clone()
    r = b - operator(x)
    b_norm = torch.sqrt(torch.clamp(torch.real(batched_inner(b, b)), min=1e-30))
    rel = torch.sqrt(torch.clamp(torch.real(batched_inner(r, r)), min=0.0)) / torch.clamp(
        b_norm, min=1e-15
    )
    initial_rel_tensor = torch.max(rel).detach()
    initial_rel = float(initial_rel_tensor.cpu())
    if mode != "fixed" and initial_rel < tol:
        info = {
            "iterations": 0.0,
            "initial_rel": initial_rel,
            "final_rel": initial_rel,
            "converged": 1.0,
        }
        return (x, info) if return_info else x

    r_hat = r.clone()
    p = torch.zeros_like(r)
    v = torch.zeros_like(r)
    rho_old = torch.ones(r.shape[0], device=r.device, dtype=r.dtype)
    alpha = torch.ones_like(rho_old)
    omega = torch.ones_like(rho_old)
    view = (slice(None),) + (None,) * (r.ndim - 1)
    iterations = 0
    converged = False
    final_rel = initial_rel
    iteration_limit = fixed_iter if mode == "fixed" else max_iter

    for iteration in range(1, iteration_limit + 1):
        iterations = iteration
        rho_new = batched_inner(r_hat, r)
        beta = _safe_complex_div(rho_new, rho_old) * _safe_complex_div(alpha, omega)
        p = r + beta[view] * (p - omega[view] * v)
        p_hat = _apply_preconditioner(preconditioner, p)
        v = operator(p_hat)
        alpha = _safe_complex_div(rho_new, batched_inner(r_hat, v))
        s = r - alpha[view] * v

        s_rel = torch.sqrt(torch.clamp(torch.real(batched_inner(s, s)), min=0.0)) / torch.clamp(
            b_norm, min=1e-15
        )
        should_check = mode == "sync" or iteration % sync_every == 0 or iteration == iteration_limit
        if mode != "fixed" and should_check:
            s_rel_max = torch.max(s_rel).detach()
            final_rel = float(s_rel_max.cpu())
            if final_rel < tol:
                x = x + alpha[view] * p_hat
                converged = True
                break

        s_hat = _apply_preconditioner(preconditioner, s)
        t = operator(s_hat)
        omega = _safe_complex_div(batched_inner(t, s), batched_inner(t, t))
        x = x + alpha[view] * p_hat + omega[view] * s_hat
        r = s - omega[view] * t

        rel = torch.sqrt(torch.clamp(torch.real(batched_inner(r, r)), min=0.0)) / torch.clamp(
            b_norm, min=1e-15
        )
        if mode != "fixed" and should_check:
            rel_max = torch.max(rel).detach()
            final_rel = float(rel_max.cpu())
            if final_rel < tol:
                converged = True
                break

        omega = torch.where(torch.abs(omega) > 1e-30, omega, torch.ones_like(omega))
        rho_old = torch.where(torch.abs(rho_new) > 1e-30, rho_new, rho_old)
    if mode == "fixed":
        rel = torch.sqrt(torch.clamp(torch.real(batched_inner(r, r)), min=0.0)) / torch.clamp(
            b_norm, min=1e-15
        )
        final_rel_tensor = torch.max(rel).detach()
        final_rel = float(final_rel_tensor.cpu())
        converged = final_rel < tol
    info = {
        "iterations": float(iterations),
        "initial_rel": initial_rel,
        "final_rel": final_rel,
        "converged": 1.0 if converged else 0.0,
    }
    return (x, info) if return_info else x


def _apply_preconditioner(preconditioner, residual: torch.Tensor) -> torch.Tensor:
    if preconditioner is None:
        return residual
    return preconditioner(residual)


def _safe_complex_div(num: torch.Tensor, den: torch.Tensor, eps: float = 1e-30) -> torch.Tensor:
    scale = torch.clamp(torch.abs(den).square(), min=eps)
    return num * torch.conj(den) / scale


def _build_lattice_galerkin_kernel_ffts(
    model: FresnelModel,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
    grid_size: int,
    *,
    quadrature_order: int,
    chunk_size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build FFT kernels for the Gaussian Green and mass operators."""
    if centers.shape[0] == grid_size * grid_size:
        offsets = _lattice_offsets(centers, grid_size)
    else:
        spacing = torch.sqrt(torch.mean(source_area))
        offsets = _lattice_offsets_from_spacing(
            grid_size,
            spacing,
            device=centers.device,
            dtype=centers.dtype,
        )
    k_pad = _galerkin_green_lattice_kernel_pad_torch(
        model,
        offsets,
        sigma[0],
        source_area[0],
        grid_size,
        quadrature_order=quadrature_order,
        chunk_size=chunk_size,
    )
    mass_pad = _gaussian_mass_lattice_kernel_pad_torch(
        offsets,
        sigma[0],
        source_area[0],
        grid_size,
        dtype=model.dtype,
    )
    k_diag = k_pad[0, 0].expand(centers.shape[0]).clone()
    mass_diag = mass_pad[0, 0].expand(centers.shape[0]).clone()
    return torch.fft.fft2(k_pad), torch.fft.fft2(mass_pad), k_diag, mass_diag


def _lattice_offsets_from_spacing(
    grid_size: int,
    spacing: torch.Tensor,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    if grid_size <= 1:
        return torch.zeros((1, 2), device=device, dtype=dtype)
    offset_index = torch.arange(
        -(grid_size - 1),
        grid_size,
        device=device,
        dtype=dtype,
    )
    offset_row, offset_col = torch.meshgrid(offset_index, offset_index, indexing="ij")
    return torch.stack([offset_row.reshape(-1), offset_col.reshape(-1)], dim=1) * spacing


def _lattice_offsets(centers: torch.Tensor, grid_size: int) -> torch.Tensor:
    if grid_size <= 1:
        return torch.zeros((1, 2), device=centers.device, dtype=centers.dtype)
    center_grid = centers.reshape(grid_size, grid_size, 2)
    row_step = center_grid[1, 0] - center_grid[0, 0]
    col_step = center_grid[0, 1] - center_grid[0, 0]
    offset_index = torch.arange(
        -(grid_size - 1),
        grid_size,
        device=centers.device,
        dtype=centers.dtype,
    )
    offset_row, offset_col = torch.meshgrid(offset_index, offset_index, indexing="ij")
    offsets = offset_row[..., None] * row_step + offset_col[..., None] * col_step
    return offsets.reshape(-1, 2)


def _scatter_lattice_kernel_values(
    values: torch.Tensor, grid_size: int, *, dtype: torch.dtype
) -> torch.Tensor:
    padded_size = 2 * grid_size
    kernel_pad = torch.zeros(
        (padded_size, padded_size),
        device=values.device,
        dtype=dtype,
    )
    offsets = torch.arange(
        -(grid_size - 1),
        grid_size,
        device=values.device,
        dtype=torch.long,
    )
    pad_indices = torch.remainder(offsets, padded_size)
    kernel_pad[pad_indices[:, None], pad_indices[None, :]] = values.reshape(
        2 * grid_size - 1,
        2 * grid_size - 1,
    ).to(dtype)
    return kernel_pad


def _galerkin_green_lattice_kernel_pad_torch(
    model: FresnelModel,
    offsets: torch.Tensor,
    sigma0: torch.Tensor,
    source_area0: torch.Tensor,
    grid_size: int,
    *,
    quadrature_order: int,
    chunk_size: int,
) -> torch.Tensor:
    """Integrate the Green function against each Gaussian pair by quadrature."""
    nodes_np, weights_np = np.polynomial.hermite.hermgauss(quadrature_order)
    qx, qy = np.meshgrid(nodes_np, nodes_np)
    wx, wy = np.meshgrid(weights_np, weights_np)
    q_nodes = torch.as_tensor(
        np.stack([qx.reshape(-1), qy.reshape(-1)], axis=1),
        device=offsets.device,
        dtype=offsets.dtype,
    )
    q_weights = torch.as_tensor(
        (wx * wy).reshape(-1),
        device=offsets.device,
        dtype=offsets.dtype,
    ).to(model.dtype)
    combined_sigma = torch.sqrt(2.0 * sigma0.square())
    scale = (model.kb**2 / np.pi) * source_area0 * source_area0
    values_out = torch.empty(offsets.shape[0], device=offsets.device, dtype=model.dtype)
    offset_chunk_size = max(chunk_size, 4096)
    for start in range(0, offsets.shape[0], offset_chunk_size):
        end = min(start + offset_chunk_size, offsets.shape[0])
        diff = (
            offsets[start:end, None, :]
            + np.sqrt(2.0) * combined_sigma[None, None, :] * q_nodes[None, :, :]
        )
        distance = torch.linalg.vector_norm(diff, dim=2).clamp_min(1e-12)
        values = _hankel_green_torch(model.kb * distance, model.dtype)
        values_out[start:end] = scale.to(model.dtype) * torch.sum(
            values * q_weights[None, :], dim=1
        )
    return _scatter_lattice_kernel_values(values_out, grid_size, dtype=model.dtype)


def _gaussian_mass_lattice_kernel_pad_torch(
    offsets: torch.Tensor,
    sigma0: torch.Tensor,
    source_area0: torch.Tensor,
    grid_size: int,
    *,
    dtype: torch.dtype,
) -> torch.Tensor:
    var = 2.0 * sigma0.square()
    exponent = -0.5 * torch.sum(offsets.square() / torch.clamp(var[None, :], min=1e-30), dim=1)
    denom = 2.0 * torch.pi * torch.sqrt(var[0] * var[1])
    values = source_area0.square() * torch.exp(exponent) / torch.clamp(denom, min=1e-30)
    return _scatter_lattice_kernel_values(values, grid_size, dtype=dtype)


def _gaussian_mass_matrix_torch(
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: torch.Tensor,
    *,
    dtype: torch.dtype,
    chunk_size: int,
) -> torch.Tensor:
    num_basis = centers.shape[0]
    out = torch.empty((num_basis, num_basis), device=centers.device, dtype=centers.dtype)
    area = source_area.reshape(-1)
    for start in range(0, num_basis, chunk_size):
        end = min(start + chunk_size, num_basis)
        delta = centers[start:end, None, :] - centers[None, :, :]
        var = sigma[start:end, None, :].square() + sigma[None, :, :].square()
        exponent = -0.5 * torch.sum(delta.square() / torch.clamp(var, min=1e-30), dim=2)
        denom = 2.0 * torch.pi * torch.sqrt(var[:, :, 0] * var[:, :, 1])
        out[start:end] = (
            area[start:end, None]
            * area[None, :]
            * torch.exp(exponent)
            / torch.clamp(denom, min=1e-30)
        )
    return out.to(dtype)


def _galerkin_green_matrix_torch(
    model: FresnelModel,
    test_centers: torch.Tensor,
    source_centers: torch.Tensor,
    test_sigma: torch.Tensor,
    source_sigma: torch.Tensor,
    test_area: torch.Tensor,
    source_area: torch.Tensor,
    *,
    quadrature_order: int,
    chunk_size: int,
) -> torch.Tensor:
    nodes_np, weights_np = np.polynomial.hermite.hermgauss(quadrature_order)
    qx, qy = np.meshgrid(nodes_np, nodes_np)
    wx, wy = np.meshgrid(weights_np, weights_np)
    q_nodes = torch.as_tensor(
        np.stack([qx.reshape(-1), qy.reshape(-1)], axis=1),
        device=test_centers.device,
        dtype=test_centers.dtype,
    )
    q_weights = torch.as_tensor(
        (wx * wy).reshape(-1),
        device=test_centers.device,
        dtype=test_centers.dtype,
    ).to(model.dtype)

    num_tests = test_centers.shape[0]
    num_sources = source_centers.shape[0]
    out = torch.empty((num_tests, num_sources), device=model.device, dtype=model.dtype)
    test_area = test_area.reshape(-1)
    source_area = source_area.reshape(-1)
    target_chunk_size = max(chunk_size, 128)

    for test_start in range(0, num_tests, target_chunk_size):
        test_end = min(test_start + target_chunk_size, num_tests)
        centers_i = test_centers[test_start:test_end]
        sigma_i = test_sigma[test_start:test_end]
        area_i = test_area[test_start:test_end]
        for source_start in range(0, num_sources, chunk_size):
            source_end = min(source_start + chunk_size, num_sources)
            centers_j = source_centers[source_start:source_end]
            sigma_j = source_sigma[source_start:source_end]
            area_j = source_area[source_start:source_end]

            delta = centers_i[:, None, :] - centers_j[None, :, :]
            combined_sigma = torch.sqrt(sigma_i[:, None, :].square() + sigma_j[None, :, :].square())
            diff = (
                delta[:, :, None, :]
                + np.sqrt(2.0) * combined_sigma[:, :, None, :] * q_nodes[None, None, :, :]
            )
            distance = torch.linalg.vector_norm(diff, dim=3).clamp_min(1e-12)
            values = _hankel_green_torch(model.kb * distance, model.dtype)
            scale = (model.kb**2 / np.pi) * area_i[:, None] * area_j[None, :]
            out[test_start:test_end, source_start:source_end] = scale.to(model.dtype) * torch.sum(
                values * q_weights[None, None, :], dim=2
            )
    return out


def _integrated_green_matrix_torch(
    model: FresnelModel,
    target_points: torch.Tensor,
    centers: torch.Tensor,
    sigma: torch.Tensor,
    source_area: float | torch.Tensor,
    *,
    quadrature_order: int,
    chunk_size: int,
) -> torch.Tensor:
    nodes_np, weights_np = np.polynomial.hermite.hermgauss(quadrature_order)
    qx, qy = np.meshgrid(nodes_np, nodes_np)
    wx, wy = np.meshgrid(weights_np, weights_np)
    q_nodes = torch.as_tensor(
        np.stack([qx.reshape(-1), qy.reshape(-1)], axis=1),
        device=target_points.device,
        dtype=target_points.dtype,
    )
    q_weights = torch.as_tensor(
        (wx * wy).reshape(-1),
        device=target_points.device,
        dtype=target_points.dtype,
    )

    num_targets = target_points.shape[0]
    num_sources = centers.shape[0]
    out = torch.empty((num_targets, num_sources), device=model.device, dtype=model.dtype)
    if isinstance(source_area, torch.Tensor):
        source_scale = source_area.to(device=model.device, dtype=target_points.dtype).reshape(-1)
    else:
        source_scale = torch.full(
            (num_sources,),
            float(source_area),
            device=model.device,
            dtype=target_points.dtype,
        )
    source_scale = (model.kb**2 / np.pi) * source_scale
    q_weights = q_weights.to(model.dtype)

    for start in range(0, num_sources, chunk_size):
        end = min(start + chunk_size, num_sources)
        chunk_centers = centers[start:end]
        chunk_sigma = sigma[start:end]
        chunk_scale = source_scale[start:end].to(model.dtype)
        source_points = (
            chunk_centers[:, None, :] + np.sqrt(2.0) * chunk_sigma[:, None, :] * q_nodes[None, :, :]
        )
        diff = target_points[:, None, None, :] - source_points[None, :, :, :]
        distance = torch.linalg.vector_norm(diff, dim=3).clamp_min(1e-12)
        values = _hankel_green_torch(model.kb * distance, model.dtype)
        out[:, start:end] = chunk_scale[None, :] * torch.sum(
            values * q_weights[None, None, :], dim=2
        )
    return out


def _harmonic_factorize_external(
    target_points: torch.Tensor,
    external: torch.Tensor,
    opts: CollocationOptions,
) -> tuple[torch.Tensor, torch.Tensor, float]:
    if external.ndim != 2:
        raise ValueError("Harmonic external factorization expects a 2D operator")
    gamma = _harmonic_coordinates(
        target_points,
        order=opts.collocation_harmonic_order,
        dtype=external.dtype,
    )
    basis = (
        torch.linalg.pinv(
            gamma,
            rtol=float(opts.collocation_harmonic_rcond),
        )
        @ external
    )
    reconstructed = gamma @ basis
    denom = torch.linalg.vector_norm(external.reshape(-1)).clamp_min(1e-30)
    rel_error = torch.linalg.vector_norm((reconstructed - external).reshape(-1)) / denom
    return gamma, basis, float(rel_error.detach().cpu())


def _harmonic_coordinates(
    target_points: torch.Tensor,
    *,
    order: int,
    dtype: torch.dtype,
) -> torch.Tensor:
    angles = torch.atan2(target_points[:, 1], target_points[:, 0])
    modes = torch.arange(
        -order,
        order + 1,
        device=target_points.device,
        dtype=target_points.dtype,
    )
    phase = angles[:, None] * modes[None, :]
    gamma = torch.polar(torch.ones_like(phase), phase)
    return gamma.to(dtype)


def _build_render_weights(
    model: FresnelModel,
    centers: torch.Tensor,
    sigma: torch.Tensor,
) -> torch.Tensor:
    points = torch.stack([model.xx.reshape(-1), model.yy.reshape(-1)], dim=1)
    dx = (points[None, :, 0] - centers[:, None, 0]) / sigma[:, None, 0]
    dy = (points[None, :, 1] - centers[:, None, 1]) / sigma[:, None, 1]
    weights = torch.exp(-0.5 * (dx.square() + dy.square()))
    weights = weights / torch.clamp(torch.sum(weights, dim=0, keepdim=True), min=1e-12)
    return weights


def _make_lattice_basis(
    model: FresnelModel, grid_size: int, sigma_scale: float
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]:
    spacing = model.length / grid_size
    centers_1d = (np.arange(grid_size, dtype=np.float64) - grid_size / 2) * spacing
    yy, xx = np.meshgrid(centers_1d, centers_1d)
    centers_np = np.stack([xx.reshape(-1), yy.reshape(-1)], axis=1)
    sigma_np = np.full_like(centers_np, sigma_scale * spacing)
    source_area_np = np.full((centers_np.shape[0],), spacing * spacing, dtype=np.float64)
    centers = torch.as_tensor(centers_np, device=model.device, dtype=model.real_dtype)
    sigma = torch.as_tensor(sigma_np, device=model.device, dtype=model.real_dtype)
    source_area = torch.as_tensor(source_area_np, device=model.device, dtype=model.real_dtype)
    return centers, sigma, source_area, spacing


def _hankel_green_torch(x: torch.Tensor, dtype: torch.dtype) -> torch.Tensor:
    hankel = torch.complex(torch.special.bessel_j0(x), torch.special.bessel_y0(x))
    return (0.25j * hankel).to(dtype)


def _synchronize_if_needed(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)
