"""Run SingleTX test cases with a shared, sequential measurement-noise stream."""

from __future__ import annotations

import pickle
from dataclasses import dataclass
from math import fsum
from pathlib import Path
from typing import Iterator

import numpy as np
import torch

from .paper2d.collocation import CollocationOptions
from .paper2d.eisp import _build_eisp_matrix_model
from .paper2d.reconstruct import reconstruct_case
from .paper2d.synthetic import build_synthetic_galerkin_model

SINGLETX_TEST_NOISE_RATIO = 0.05
SINGLETX_TEST_SEED = 1000


@dataclass(frozen=True)
class BenchmarkMeans:
    count: int
    ssim: float
    rrmse: float
    psnr: float


def sequential_noisy_fields(
    real: np.ndarray,
    imag: np.ndarray,
    *,
    first: int,
    noise_ratio: float,
    seed: int,
) -> Iterator[np.ndarray]:
    """Match SingleTX's real-then-imaginary draws over samples 0, 1, ... ."""
    real = np.asarray(real, dtype=np.float64)
    imag = np.asarray(imag, dtype=np.float64)
    if real.shape != imag.shape or real.ndim != 3:
        raise ValueError("Expected matching (samples, receivers, transmitters) fields")
    if not 1 <= first <= real.shape[0]:
        raise ValueError(f"first must be between 1 and {real.shape[0]}")
    if noise_ratio < 0:
        raise ValueError("noise_ratio must be non-negative")

    rng = np.random.RandomState(seed)
    for index in range(first):
        energy = float(np.sqrt(np.mean(real[index] ** 2 + imag[index] ** 2)) / np.sqrt(2.0))
        scale = energy * noise_ratio
        noisy_real = real[index] + scale * rng.randn(*real[index].shape)
        noisy_imag = imag[index] + scale * rng.randn(*imag[index].shape)
        yield noisy_real + 1j * noisy_imag


def run_singletx_benchmark(
    case: str,
    source: Path,
    output_dir: Path,
    options: CollocationOptions,
    *,
    first: int = 100,
    device: str = "cuda",
    dtype: torch.dtype = torch.complex64,
) -> BenchmarkMeans:
    """Evaluate samples from one official 2-D test pickle."""
    if case not in {"mnist", "cylinder"}:
        raise ValueError(f"Unsupported SingleTX benchmark: {case}")
    with source.open("rb") as stream:
        archive = pickle.load(stream)  # nosec: use only the trusted official download
    raw = archive["data"]
    params = archive["params"]
    if int(params["num_groups"]) != len(raw["epsilon_gt"]):
        raise ValueError("Inconsistent sample count in SingleTX pickle")

    e_inc = raw["E_inc_real"] + 1j * raw["E_inc_imag"]
    phi = raw["Phi_mat_real"] + 1j * raw["Phi_mat_imag"]
    r_mat = raw["R_mat_real"] + 1j * raw["R_mat_imag"]
    x_dom = np.asarray(raw["x_dom"], dtype=np.float64)
    y_dom = np.asarray(raw["y_dom"], dtype=np.float64)
    xy_t = np.asarray(raw["xy_t"], dtype=np.float64)
    xy_r = np.asarray(raw.get("xy_r", np.zeros((raw["E_s_real"].shape[1], 2))), dtype=np.float64)
    scores: list[tuple[float, float, float]] = []
    fields = sequential_noisy_fields(
        raw["E_s_real"],
        raw["E_s_imag"],
        first=first,
        noise_ratio=SINGLETX_TEST_NOISE_RATIO,
        seed=SINGLETX_TEST_SEED,
    )
    for index, e_s in enumerate(fields):
        model = _build_eisp_matrix_model(
            file_name=f"{case}_sample{index}",
            epsilon=np.asarray(raw["epsilon_gt"][index], dtype=np.float64),
            x_dom=x_dom,
            y_dom=y_dom,
            e_inc=e_inc,
            e_s=e_s,
            phi=phi,
            r_mat=r_mat,
            xy_t=xy_t,
            xy_r=xy_r,
            lam_0=float(params["lam_0"]),
            max_dom=float(params["MAX"]),
            device=device,
            dtype=dtype,
            domain_operator="kernel",
        )
        result = reconstruct_case(
            model,
            case,
            f"sample{index}",
            output_dir / f"sample_{index:04d}",
            options,
            build_synthetic_galerkin_model,
            visualize_final=False,
            verbose=False,
        )
        scores.append((result.ssim, result.rrmse, result.psnr))
        if (index + 1) % 10 == 0 or index + 1 == first:
            print(f"{case.capitalize()} benchmark: {index + 1}/{first} cases", flush=True)

    return BenchmarkMeans(
        count=first,
        ssim=fsum(row[0] for row in scores) / first,
        rrmse=fsum(row[1] for row in scores) / first,
        psnr=fsum(row[2] for row in scores) / first,
    )
