"""Small complex tensor operations used by the Galerkin solver."""

from __future__ import annotations

import torch


def complex_norm(x: torch.Tensor) -> torch.Tensor:
    return torch.linalg.vector_norm(x.reshape(-1))


def batched_inner(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return torch.sum(torch.conj(x) * y, dim=tuple(range(1, x.ndim)))
