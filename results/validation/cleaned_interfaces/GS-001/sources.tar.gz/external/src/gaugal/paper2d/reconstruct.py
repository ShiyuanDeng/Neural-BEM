"""Reconstruction loop, metrics, and result serialization."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from time import perf_counter
from typing import Callable, Union

import matplotlib

matplotlib.use("Agg")
import numpy as np
import torch
from matplotlib import pyplot as plt

from .collocation import (
    CollocationOptions,
    GaussianCollocationModel,
    _collocation_linear_solver,
    _collocation_preconditioner_name,
    _collocation_step_gradient,
    _collocation_tv_prox,
    _linear_stats_metrics,
    _operator_storage,
    _reset_linear_stats,
    _reset_timing_stats,
    _resolve_collocation_tv_mode,
    collocation_forward_prop,
    collocation_gradient,
    collocation_sensor_forward,
    render_collocation_contrast,
)
from .fresnel import FresnelModel
from .metrics import single_tx_metrics, snr_db
from .operators import complex_norm
from .settings import PaperCaseSettings, SolverControls
from .solver import _lambda_value, _lambda_value_for_iteration, _tv_max_iter_for_iteration
from .synthetic import SyntheticScatteringModel

# This alias is evaluated at import time, unlike postponed annotations.
# Keep the shared BEM environment usable without changing solver numerics.
PaperModel = Union[FresnelModel, SyntheticScatteringModel]


@dataclass
class ReconstructionResult:
    """Metrics and timings for one reconstruction."""

    dataset: str
    sample: str
    output_dir: str
    prediction_path: str
    method: str
    num_iter: int
    num_gaussians: int
    optimization_sec: float
    build_sec: float
    evaluation_sec: float
    visualization_sec: float
    rel_data_error: float
    snr_db: float
    rrmse: float
    psnr: float
    ssim: float
    amp_max: float
    amp_mean: float
    linear_solves: float
    linear_iterations: float
    linear_avg_iterations: float


def paper_options(
    settings: PaperCaseSettings,
    controls: SolverControls,
) -> CollocationOptions:
    """Combine case settings with solver controls."""
    num_iter = settings.num_iter if controls.num_iter is None else int(controls.num_iter)
    tv_max_iter = (
        settings.tv_max_iter if controls.tv_max_iter is None else int(controls.tv_max_iter)
    )
    return CollocationOptions(
        num_iter=num_iter,
        lambda_scale=settings.lambda_scale,
        lambda_schedule=settings.lambda_schedule,
        lambda_final_fraction=settings.lambda_final_fraction,
        lambda_decay_start_fraction=settings.lambda_decay_start_fraction,
        tv_max_iter=tv_max_iter,
        tv_schedule="fixed",
        tv_tol=1e-4,
        contrast_max=settings.contrast_max,
        pcg_tol=controls.pcg_tol,
        pcg_max_iter=controls.pcg_max_iter,
        collocation_form="galerkin",
        collocation_linear_solver="bicgstab",
        collocation_preconditioner="auto",
        collocation_matvec_mode="fft",
        collocation_fft_assembly="kernel",
        collocation_grid_size=settings.grid_size,
        collocation_sigma_scale=settings.sigma_scale,
        collocation_step_size=settings.step_size,
        collocation_tv_mode="coefficient",
        collocation_contrast_mode="auto",
        collocation_chunk_size=controls.collocation_chunk_size,
        collocation_quadrature_order=controls.collocation_quadrature_order,
        collocation_external_operator="dense",
        collocation_bicgstab_mode=controls.bicgstab_mode,
        collocation_bicgstab_sync_every=controls.bicgstab_sync_every,
        collocation_bicgstab_fixed_iter=controls.bicgstab_fixed_iter,
        collocation_reuse_fft_workspace=controls.reuse_fft_workspace,
        collocation_profile=controls.profile,
    )


def reconstruct_case(
    model: PaperModel,
    dataset: str,
    sample: str,
    out_dir: Path,
    opts: CollocationOptions,
    collocation_builder: Callable[..., GaussianCollocationModel],
    *,
    visualize_final: bool,
    verbose: bool = True,
) -> ReconstructionResult:
    """Optimize Gaussian coefficients with accelerated proximal updates."""
    out_dir.mkdir(parents=True, exist_ok=True)
    total_start = perf_counter()
    collocation = collocation_builder(model, opts)
    _synchronize(model.device)
    build_sec = perf_counter() - total_start
    linear_solver = _collocation_linear_solver(collocation, opts)
    if verbose:
        print(
            f"[{dataset}:{sample}] built basis={collocation.num_basis}, "
            f"solver={linear_solver}, preconditioner="
            f"{_collocation_preconditioner_name(linear_solver, opts, collocation)}, "
            f"matvec={collocation.matvec_mode}, storage={_operator_storage(collocation)}, "
            f"tv={_resolve_collocation_tv_mode(collocation, opts)}, "
            f"step={opts.collocation_step_size:g}, build={collocation.build_seconds:.3f}s"
        )

    coeff = torch.zeros(collocation.num_basis, device=model.device, dtype=model.real_dtype)
    momentum_coeff = coeff.clone()
    tv_p0 = None
    tv_q0 = None
    q_momentum = 1.0  # FISTA's scalar extrapolation state.
    u = collocation.uinc.clone()
    v = torch.zeros_like(collocation.uinc)
    base_lam = _lambda_value(model, opts)
    step_size = float(opts.collocation_step_size)
    last_linear_stats = _linear_stats_metrics(collocation)
    optimization_sec = 0.0

    for ind_iter in range(1, opts.num_iter + 1):
        _reset_linear_stats(collocation)
        _reset_timing_stats(collocation)
        _synchronize(model.device)
        iter_start = perf_counter()
        with torch.no_grad():
            # Project extrapolated coefficients before evaluating the gradient.
            lam = _lambda_value_for_iteration(base_lam, opts, ind_iter)
            coeff_projected = torch.clamp(momentum_coeff, min=0.0, max=opts.contrast_max)
            grad_a, u, v, _ = collocation_gradient(model, collocation, coeff_projected, u, v, opts)
            step_grad = _collocation_step_gradient(collocation, grad_a, opts)
            tv_iter_budget = _tv_max_iter_for_iteration(opts, ind_iter, force_full=False)
            coeff_candidate = coeff_projected - step_size * step_grad
            coeff_next, tv_p0, tv_q0, _ = _collocation_tv_prox(
                model,
                collocation,
                coeff_candidate,
                lam * step_size,
                tv_p0,
                tv_q0,
                opts,
                max_iter=tv_iter_budget,
            )
            # Apply damped FISTA extrapolation.
            q_next = 0.5 * (1.0 + (1.0 + 4.0 * q_momentum * q_momentum) ** 0.5)
            momentum_weight = opts.alpha * ((q_momentum - 1.0) / q_next)
            momentum_coeff = coeff_next + momentum_weight * (coeff_next - coeff)
            q_momentum = q_next
            coeff = coeff_next
        _synchronize(model.device)
        optimization_sec += perf_counter() - iter_start
        last_linear_stats = _linear_stats_metrics(collocation)

        if verbose and (ind_iter == 1 or ind_iter == opts.num_iter or ind_iter % 50 == 0):
            print(
                f"[{dataset}:{sample}] iter {ind_iter}/{opts.num_iter}: "
                f"fair_opt={optimization_sec:.2f}s, "
                f"linearIters={last_linear_stats['linear_iterations']:.0f}, "
                f"ampMax={float(torch.max(coeff).detach().cpu()):.4g}"
            )

    final_coeff = torch.clamp(coeff.detach(), min=0.0, max=opts.contrast_max)
    eval_start = perf_counter()
    final_metrics, final_recon, final_data_pred = final_evaluation(
        model, collocation, final_coeff, u, opts
    )
    _synchronize(model.device)
    evaluation_sec = perf_counter() - eval_start
    prediction_path = out_dir / "final_predicted_data.npz"
    save_final_prediction_data(model, final_recon, final_data_pred, prediction_path)

    visualization_sec = 0.0
    if visualize_final:
        vis_start = perf_counter()
        save_final_visualization(
            tensor_to_numpy(model.nominal_truth),
            tensor_to_numpy(final_recon),
            out_dir / "final_reconstruction.png",
            title=f"{dataset} {sample}",
        )
        visualization_sec += perf_counter() - vis_start

    result = ReconstructionResult(
        dataset=dataset,
        sample=sample,
        output_dir=str(out_dir),
        prediction_path=str(prediction_path),
        method="galerkin-kernel",
        num_iter=int(opts.num_iter),
        num_gaussians=int(collocation.num_basis),
        optimization_sec=float(optimization_sec),
        build_sec=float(build_sec),
        evaluation_sec=float(evaluation_sec),
        visualization_sec=float(visualization_sec),
        rel_data_error=float(final_metrics["rel_data_error"]),
        snr_db=float(final_metrics["snr_db"]),
        rrmse=float(final_metrics["rrmse"]),
        psnr=float(final_metrics["psnr"]),
        ssim=float(final_metrics["ssim"]),
        amp_max=float(final_metrics["amp_max"]),
        amp_mean=float(final_metrics["amp_mean"]),
        linear_solves=float(last_linear_stats["linear_solves"]),
        linear_iterations=float(last_linear_stats["linear_iterations"]),
        linear_avg_iterations=float(last_linear_stats["linear_avg_iterations"]),
    )
    write_summary(out_dir / "metrics.csv", [result])
    write_options(out_dir / "settings.csv", opts)
    if verbose:
        print_result(result)
    return result


def final_evaluation(
    model: PaperModel,
    collocation: GaussianCollocationModel,
    coeff: torch.Tensor,
    u_warm: torch.Tensor,
    opts: CollocationOptions,
) -> tuple[dict[str, float], torch.Tensor, torch.Tensor]:
    with torch.no_grad():
        u_eval = collocation_forward_prop(collocation, coeff, u_warm, opts)
        data_pred = collocation_sensor_forward(model, collocation, coeff, u_eval)
        recon = render_collocation_contrast(model, collocation, coeff)
        metrics = reconstruction_metrics(model, recon, data_pred)
        metrics["amp_max"] = float(torch.max(coeff).detach().cpu())
        metrics["amp_mean"] = float(torch.mean(coeff).detach().cpu())
    return metrics, recon, data_pred


def reconstruction_metrics(
    model: PaperModel, recon: torch.Tensor, data_pred: torch.Tensor
) -> dict[str, float]:
    """Use contrast for SNR and absolute permittivity for SingleTX scores."""
    truth_np = tensor_to_numpy(model.nominal_truth)
    recon_np = tensor_to_numpy(recon)
    data_rel = complex_norm(data_pred - model.data) / torch.clamp(
        complex_norm(model.data), min=torch.finfo(model.real_dtype).eps
    )
    eisp_metrics = single_tx_metrics(recon_np + 1.0, truth_np + 1.0)
    return {
        "rel_data_error": float(data_rel.detach().cpu()),
        "snr_db": snr_db(recon_np, truth_np),
        **eisp_metrics,
    }


def save_final_visualization(
    truth: np.ndarray, recon: np.ndarray, path: Path, *, title: str
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    error = np.abs(recon - truth)
    vmin = min(float(np.min(truth)), float(np.min(recon)))
    vmax = max(float(np.max(truth)), float(np.max(recon)))
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.4), constrained_layout=True)
    images = [
        axes[0].imshow(truth, cmap="viridis", vmin=vmin, vmax=vmax),
        axes[1].imshow(recon, cmap="viridis", vmin=vmin, vmax=vmax),
        axes[2].imshow(error, cmap="magma"),
    ]
    axes[0].set_title("Truth")
    axes[1].set_title("Reconstruction")
    axes[2].set_title("Absolute Error")
    for ax in axes:
        ax.set_xticks([])
        ax.set_yticks([])
    fig.suptitle(title)
    fig.colorbar(images[1], ax=axes[:2], shrink=0.75)
    fig.colorbar(images[2], ax=axes[2], shrink=0.75)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def save_final_prediction_data(
    model: PaperModel, recon: torch.Tensor, data_pred: torch.Tensor, path: Path
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    measured = tensor_to_numpy(model.data)
    predicted = tensor_to_numpy(data_pred)
    truth = tensor_to_numpy(model.nominal_truth)
    reconstruction = tensor_to_numpy(recon)
    receiver_mask = tensor_to_numpy(model.receiver_mask).astype(bool)
    np.savez_compressed(
        path,
        data_pred_real=np.real(predicted),
        data_pred_imag=np.imag(predicted),
        data_measured_real=np.real(measured),
        data_measured_imag=np.imag(measured),
        receiver_mask=receiver_mask,
        reconstruction=reconstruction,
        truth=truth,
        epsilon_pred=reconstruction + 1.0,
        epsilon_truth=truth + 1.0,
    )


def write_summary(path: Path, rows: list[ReconstructionResult]) -> None:
    if not rows:
        return
    write_rows(path, [asdict(row) for row in rows])


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_options(path: Path, opts: CollocationOptions) -> None:
    rows = [{"parameter": key, "value": value} for key, value in asdict(opts).items()]
    write_rows(path, rows)


def print_result(row: ReconstructionResult) -> None:
    print(
        f"[{row.dataset}:{row.sample}] done: opt={row.optimization_sec:.2f}s, "
        f"SNR={row.snr_db:.3f} dB, RRMSE={row.rrmse:.5f}, "
        f"PSNR={row.psnr:.2f}, SSIM={row.ssim:.4f}, "
        f"metrics={row.output_dir}/metrics.csv"
    )


def tensor_to_numpy(value: torch.Tensor) -> np.ndarray:
    return value.detach().cpu().numpy()


def _synchronize(device: torch.device | str) -> None:
    device = torch.device(device)
    if device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.synchronize(device)
