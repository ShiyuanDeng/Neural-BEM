"""Parse Fresnel .exp measurements and construct the calibrated 2-D model."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from scipy.special import hankel1


@dataclass
class FresnelModel:
    """Experimental fields, acquisition geometry, and nominal target."""

    file_name: str
    frequency_ghz: float
    wavelength: float
    kb: float
    length: float
    nx: int
    ny: int
    dx: float
    dy: float
    x: torch.Tensor
    y: torch.Tensor
    xx: torch.Tensor
    yy: torch.Tensor
    data: torch.Tensor
    receiver_mask: torch.Tensor
    nominal_truth: torch.Tensor
    x_transmit: torch.Tensor
    y_transmit: torch.Tensor
    x_receive: torch.Tensor
    y_receive: torch.Tensor
    amp: complex

    @property
    def device(self) -> torch.device:
        return self.data.device

    @property
    def dtype(self) -> torch.dtype:
        return self.data.dtype

    @property
    def real_dtype(self) -> torch.dtype:
        return self.x.dtype

    @property
    def cell_area(self) -> float:
        return self.dx * self.dy


def build_fresnel_model(
    file_name: str,
    data_dir: str | Path,
    *,
    frequency_ghz: float = 3.0,
    n: int = 128,
    length: float = 0.1536,
    sensor_radius: float = 1.67,
    device: str | torch.device = "cuda",
    dtype: torch.dtype = torch.complex64,
) -> FresnelModel:
    """Use the original .exp acquisition and the paper's spatial discretization."""

    data_dir = Path(data_dir)
    exp_path = data_dir / f"{file_name}.exp"
    if not exp_path.exists():
        raise FileNotFoundError(f"Fresnel data file not found: {exp_path}")

    if dtype not in (torch.complex64, torch.complex128):
        raise ValueError("dtype must be torch.complex64 or torch.complex128")

    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    device = torch.device(device)

    full_data = np.loadtxt(exp_path, comments="#")
    frequencies = np.unique(full_data[:, 2])
    if not np.any(np.isclose(frequencies, frequency_ghz)):
        raise ValueError(f"Frequency {frequency_ghz:g} GHz not found in {file_name}")

    c = 299_792_458.0
    wavelength = c / frequency_ghz / 1e9
    kb = 2.0 * np.pi / wavelength

    nx = int(n)
    ny = int(n)
    if nx < 2 or ny < 2:
        raise ValueError("n must be at least 2")
    dx = length / nx
    dy = length / ny
    x_pix = (np.arange(-nx / 2, nx / 2) * dx).astype(np.float64)
    y_pix = (np.arange(-ny / 2, ny / 2) * dy).astype(np.float64)
    x_grid, y_grid = np.meshgrid(x_pix, y_pix)

    transmitter_angles = _transmitter_angles(file_name)
    receiver_angles = np.arange(360, dtype=np.float64) * np.pi / 180.0
    num_trans = transmitter_angles.size
    num_rec = receiver_angles.size

    x_transmit = sensor_radius * np.cos(transmitter_angles)
    y_transmit = sensor_radius * np.sin(transmitter_angles)
    x_receive = sensor_radius * np.cos(receiver_angles)
    y_receive = sensor_radius * np.sin(receiver_angles)

    receiver_mask = np.zeros((num_trans, num_rec), dtype=bool)
    utot_meas = np.zeros((num_trans, num_rec), dtype=np.complex128)
    uinc_meas = np.zeros((num_trans, num_rec), dtype=np.complex128)

    # The .exp file uses one-based sensor IDs and the opposite phasor
    # convention; conjugation here matches the paper's forward model.
    freq_rows = np.isclose(full_data[:, 2], frequency_ghz)
    for ind_trans in range(num_trans):
        rows = (full_data[:, 0] == ind_trans + 1) & freq_rows
        active = full_data[rows]
        rec_idx = active[:, 1].astype(np.int64) - 1
        receiver_mask[ind_trans, rec_idx] = True
        utot_meas[ind_trans, rec_idx] = np.conj(active[:, 3] + 1j * active[:, 4])
        uinc_meas[ind_trans, rec_idx] = np.conj(active[:, 5] + 1j * active[:, 6])

    data = utot_meas - uinc_meas

    dist_tr = np.hypot(
        x_transmit[:, None] - x_receive[None, :],
        y_transmit[:, None] - y_receive[None, :],
    )
    uinc_pred_rec = _hankel_green(kb * dist_tr)
    angle_step = _transmitter_angle_step_degrees(file_name)
    # Calibrate source amplitude at the receiver opposite each transmitter.
    amp_set = np.zeros(num_trans, dtype=np.complex128)
    for ind_trans in range(num_trans):
        rec_index = (181 + ind_trans * angle_step) % 360
        if rec_index == 0:
            rec_index = 360
        rec_index -= 1
        amp_set[ind_trans] = uinc_meas[ind_trans, rec_index] / uinc_pred_rec[ind_trans, rec_index]
    amp = amp_set.mean()

    # This is nominal geometry, not an independent measured truth image.
    nominal_truth = _nominal_truth(file_name, x_grid, y_grid)

    x_t = torch.as_tensor(x_pix, device=device, dtype=real_dtype)
    y_t = torch.as_tensor(y_pix, device=device, dtype=real_dtype)
    xx_t = torch.as_tensor(x_grid, device=device, dtype=real_dtype)
    yy_t = torch.as_tensor(y_grid, device=device, dtype=real_dtype)
    data_t = torch.as_tensor(data, device=device, dtype=dtype)
    mask_t = torch.as_tensor(receiver_mask, device=device)
    truth_t = torch.as_tensor(nominal_truth, device=device, dtype=real_dtype)
    x_trans_t = torch.as_tensor(x_transmit, device=device, dtype=real_dtype)
    y_trans_t = torch.as_tensor(y_transmit, device=device, dtype=real_dtype)
    x_rec_t = torch.as_tensor(x_receive, device=device, dtype=real_dtype)
    y_rec_t = torch.as_tensor(y_receive, device=device, dtype=real_dtype)

    return FresnelModel(
        file_name=file_name,
        frequency_ghz=frequency_ghz,
        wavelength=wavelength,
        kb=kb,
        length=length,
        nx=nx,
        ny=ny,
        dx=dx,
        dy=dy,
        x=x_t,
        y=y_t,
        xx=xx_t,
        yy=yy_t,
        data=data_t,
        receiver_mask=mask_t,
        nominal_truth=truth_t,
        x_transmit=x_trans_t,
        y_transmit=y_trans_t,
        x_receive=x_rec_t,
        y_receive=y_rec_t,
        amp=complex(amp),
    )


def _hankel_green(x: np.ndarray) -> np.ndarray:
    return 1j * 0.25 * hankel1(0, x)


def _transmitter_angles(file_name: str) -> np.ndarray:
    if file_name in {"FoamDielIntTM", "FoamDielExtTM"}:
        return np.arange(0, 360, 45, dtype=np.float64) * np.pi / 180.0
    if file_name == "FoamTwinDielTM":
        return np.arange(0, 360, 20, dtype=np.float64) * np.pi / 180.0
    raise ValueError(f"No transmitter geometry configured for {file_name}")


def _transmitter_angle_step_degrees(file_name: str) -> int:
    if file_name in {"FoamDielIntTM", "FoamDielExtTM"}:
        return 45
    if file_name == "FoamTwinDielTM":
        return 20
    raise ValueError(f"No transmitter step configured for {file_name}")


def _nominal_truth(file_name: str, xx: np.ndarray, yy: np.ndarray) -> np.ndarray:
    foam_contrast = 1.45 - 1.0
    plastic_contrast = 3.0 - 1.0
    foam_radius = 0.08 / 2.0
    plastic_radius = 0.031 / 2.0

    truth = np.zeros_like(xx, dtype=np.float64)
    truth[xx**2 + yy**2 <= foam_radius**2] = foam_contrast

    if file_name == "FoamDielIntTM":
        centers = [(-0.005, 0.0)]
    elif file_name == "FoamDielExtTM":
        centers = [(-0.0555, 0.0)]
    elif file_name == "FoamTwinDielTM":
        centers = [(-0.005, 0.0), (-0.0555, 0.0)]
    else:
        raise ValueError(f"No nominal target configured for {file_name}")

    for cx, cy in centers:
        mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= plastic_radius**2
        truth[mask] = plastic_contrast
    return truth
