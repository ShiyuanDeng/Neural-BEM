"""2-D Gaussian--Galerkin reconstruction modules."""
