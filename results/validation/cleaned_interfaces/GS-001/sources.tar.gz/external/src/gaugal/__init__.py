"""Gau-Gal: reproducible 2-D Gaussian--Galerkin inverse scattering."""

__version__ = "0.1.0"
