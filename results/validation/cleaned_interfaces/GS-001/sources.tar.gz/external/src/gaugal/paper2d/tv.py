"""Coefficient-grid isotropic TV proximal operator with periodic differences."""

from __future__ import annotations

import torch

_TV_FREQ_RESPONSE_CACHE: dict[tuple[str, int | None, torch.dtype, int, int], torch.Tensor] = {}


def denoise_tv(
    y: torch.Tensor,
    lam: float | torch.Tensor,
    *,
    p0: torch.Tensor | None = None,
    q0: torch.Tensor | None = None,
    max_iter: int = 100,
    tol: float = 1e-4,
    lower_bound: float = 0.0,
    upper_bound: float = float("inf"),
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Solve the bounded coefficient-grid TV proximal step with ADMM.

    ``p0`` and ``q0`` warm-start the auxiliary and dual states across iterations.
    """

    sig_size = y.shape
    ny, nx = sig_size
    real_dtype = y.dtype
    complex_dtype = torch.complex64 if real_dtype == torch.float32 else torch.complex128

    y_flat = y.reshape(-1).clone()
    y_flat = torch.clamp(y_flat, min=lower_bound, max=upper_bound)

    n_dual = 2 * y_flat.numel()
    s = (
        torch.zeros(n_dual, device=y.device, dtype=real_dtype)
        if p0 is None
        else p0.reshape(-1).clone()
    )
    q = (
        torch.zeros(n_dual, device=y.device, dtype=real_dtype)
        if q0 is None
        else q0.reshape(-1).clone()
    )

    freq_response = _tv_freq_response(ny, nx, y.device, real_dtype, complex_dtype)

    x = y_flat
    mu = 1.0
    lam_value = float(lam.detach().cpu()) if isinstance(lam, torch.Tensor) else float(lam)
    dx_current = _forward_tv(x, nx, ny)
    iter_count = 0
    while lam_value / mu > 0:
        denom = torch.linalg.vector_norm(dx_current)
        rel = torch.linalg.vector_norm(s - dx_current) / torch.clamp(denom, min=1e-12)
        if iter_count > 0 and rel <= tol:
            break

        iter_count += 1
        x_rhs = y_flat + mu * _adjoint_tv(s + q / mu, nx, ny)
        x_img = x_rhs.reshape(ny, nx).to(complex_dtype)
        x_img = torch.fft.ifft2(torch.fft.fft2(x_img) / (1.0 + mu * freq_response))
        x = torch.real(x_img).reshape(-1).to(real_dtype)

        dx_current = _forward_tv(x, nx, ny)
        s = _tv_l21_shrink(dx_current - q / mu, lam_value / mu)
        q = q + mu * (s - dx_current)

        if iter_count >= max_iter:
            break

    return x.reshape(sig_size), s, q, iter_count


def _forward_tv(x: torch.Tensor, nx: int, ny: int) -> torch.Tensor:
    img = x.reshape(ny, nx)
    dx = torch.roll(img, shifts=-1, dims=1) - img
    dy = torch.roll(img, shifts=-1, dims=0) - img
    return torch.cat([dx.reshape(-1), dy.reshape(-1)])


def _adjoint_tv(x: torch.Tensor, nx: int, ny: int) -> torch.Tensor:
    dx = x[: nx * ny].reshape(ny, nx)
    dy = x[nx * ny :].reshape(ny, nx)
    y = torch.roll(dy, shifts=1, dims=0) - dy + torch.roll(dx, shifts=1, dims=1) - dx
    return y.reshape(-1)


def _tv_l21_shrink(a: torch.Tensor, gamma: float) -> torch.Tensor:
    half = a.numel() // 2
    paired = torch.stack([a[:half], a[half:]], dim=1)
    norm = torch.sqrt(torch.sum(torch.abs(paired) ** 2, dim=1))
    shrink = torch.clamp(norm - gamma, min=0.0) / (norm + 1e-6)
    shrunk = paired * shrink[:, None]
    return torch.cat([shrunk[:, 0], shrunk[:, 1]])


def _tv_freq_response(
    ny: int,
    nx: int,
    device: torch.device,
    real_dtype: torch.dtype,
    complex_dtype: torch.dtype,
) -> torch.Tensor:
    key = (device.type, device.index, complex_dtype, ny, nx)
    cached = _TV_FREQ_RESPONSE_CACHE.get(key)
    if cached is not None and cached.device == device:
        return cached

    wx = 2.0 * torch.pi * torch.arange(nx, device=device, dtype=real_dtype) / nx
    wy = 2.0 * torch.pi * torch.arange(ny, device=device, dtype=real_dtype) / ny
    wy_grid, wx_grid = torch.meshgrid(wy, wx, indexing="ij")
    freq_response = (
        4.0
        - torch.exp(-1j * wx_grid.to(complex_dtype))
        - torch.exp(1j * wx_grid.to(complex_dtype))
        - torch.exp(-1j * wy_grid.to(complex_dtype))
        - torch.exp(1j * wy_grid.to(complex_dtype))
    )
    _TV_FREQ_RESPONSE_CACHE[key] = freq_response
    return freq_response
