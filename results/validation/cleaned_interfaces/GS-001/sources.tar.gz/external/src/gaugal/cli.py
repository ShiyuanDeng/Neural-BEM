"""Run 2-D inverse-scattering cases from the supported datasets."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import tempfile
from dataclasses import asdict
from pathlib import Path

import torch

from .benchmark import run_singletx_benchmark
from .paper2d.au import load_au_case
from .paper2d.collocation import CollocationOptions, build_gaussian_collocation_model
from .paper2d.eisp import load_singletx_pickle_case
from .paper2d.fresnel import build_fresnel_model
from .paper2d.reconstruct import paper_options, reconstruct_case
from .paper2d.settings import PaperCaseSettings, SolverControls
from .paper2d.synthetic import build_synthetic_galerkin_model

SINGLETX_CASES = ("mnist", "cylinder")
RUN_CASES = (*SINGLETX_CASES, "au")
PAPER_CASES = (*RUN_CASES, "fresnel")
BENCHMARK_CONFIG_FILES = {
    "mnist": "mnist.json",
    "cylinder": "cylinder_benchmark.json",
}
FRESNEL_TARGETS = ("FoamDielIntTM", "FoamDielExtTM", "FoamTwinDielTM")
FRESNEL_FREQUENCIES = ("3GHz", "4GHz", "5GHz")
FRESNEL_CASES_FILE = Path("configs/fresnel_cases.json")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolved_path(path: str | Path) -> Path:
    return Path(path).expanduser().resolve()


def _case_settings(config: dict) -> PaperCaseSettings:
    """Translate a readable case JSON into typed numerical settings."""
    return PaperCaseSettings(
        lambda_scale=float(config["lambda_scale"]),
        sigma_scale=float(config["sigma_scale"]),
        step_size=float(config["step_size"]),
        contrast_max=float(config["contrast_max"]),
        grid_size=int(config["grid_size"]),
        num_iter=int(config["num_iter"]),
        tv_max_iter=int(config["tv_max_iter"]),
        lambda_schedule=str(config["lambda_schedule"]),
        lambda_final_fraction=float(config["lambda_final_fraction"]),
        lambda_decay_start_fraction=float(config["lambda_decay_start_fraction"]),
    )


def _write_provenance(
    output_dir: Path,
    config_path: Path,
    config: dict,
    input_path: Path,
    input_files: list[Path],
    options: CollocationOptions,
    device: str,
    sample_name: str,
) -> None:
    """Record exact inputs and code before starting a potentially long run."""
    core_dir = Path(__file__).parent / "paper2d"
    manifest = {
        "config": config,
        "config_sha256": _sha256(config_path),
        "resolved_input": str(input_path),
        "resolved_output": str(output_dir),
        "resolved_sample": sample_name,
        "input_sha256": {path.name: _sha256(path) for path in input_files},
        "core_sha256": {path.name: _sha256(path) for path in sorted(core_dir.glob("*.py"))},
        "resolved_options": {key: str(value) for key, value in asdict(options).items()},
        "device": device,
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(device) if device.startswith("cuda") else None,
    }
    (output_dir / "provenance.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )


def _reconstruct(args: argparse.Namespace) -> None:
    config_path = _resolved_path(args.config)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    case = config["case"]
    if case not in PAPER_CASES:
        raise ValueError(f"Unsupported paper case: {case}")
    device = args.device or config.get("device", "cuda")
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    precision = config.get("precision", "single")
    if precision not in {"single", "double"}:
        raise ValueError(f"Unsupported precision: {precision}")
    complex_dtype = torch.complex64 if precision == "single" else torch.complex128
    input_path = _resolved_path(args.input or config["input"])
    if not input_path.exists():
        raise FileNotFoundError(f"Input not found: {input_path}. See README.md for data setup.")
    output_dir = _resolved_path(args.output or config["output"])
    options = paper_options(_case_settings(config), SolverControls(num_iter=args.iterations))
    if case == "fresnel":
        if input_path.suffix != ".exp":
            raise ValueError("Fresnel input must be the original .exp file")
        model = build_fresnel_model(
            input_path.stem,
            input_path.parent,
            frequency_ghz=float(config["frequency_ghz"]),
            sensor_radius=float(config["sensor_radius_m"]),
            n=int(config["image_size"]),
            device=device,
            dtype=complex_dtype,
        )
        builder = build_gaussian_collocation_model
        input_files = [input_path]
    elif case == "au":
        if input_path.suffix != ".npz":
            raise ValueError("AU input must be the bundled .npz archive")
        model = load_au_case(
            input_path,
            device=device,
            dtype=complex_dtype,
            test_noise_ratio=float(config["noise_ratio"]),
            noise_seed=int(config["noise_seed"]),
        )
        builder = build_synthetic_galerkin_model
        input_files = [input_path]
    else:
        if input_path.suffix != ".pkl":
            raise ValueError("MNIST and Cylinder input must be the official test pickle")
        sample_index = getattr(args, "sample_index", None)
        model = load_singletx_pickle_case(
            input_path,
            sample_index=int(config["sample_index"] if sample_index is None else sample_index),
            file_name=case,
            device=device,
            dtype=complex_dtype,
            domain_operator="kernel",
            test_noise_ratio=float(config["noise_ratio"]),
            noise_seed=int(config["noise_seed"]),
        )
        builder = build_synthetic_galerkin_model
        input_files = [input_path]
    output_dir.mkdir(parents=True, exist_ok=True)
    sample_name = str(getattr(args, "sample_name", None) or config["sample"])
    _write_provenance(
        output_dir, config_path, config, input_path, input_files, options, str(device), sample_name
    )
    result = reconstruct_case(
        model,
        case,
        sample_name,
        output_dir,
        options,
        builder,
        visualize_final=not args.no_plot,
    )
    (output_dir / "metrics.json").write_text(
        json.dumps(asdict(result), indent=2) + "\n", encoding="utf-8"
    )


def _run_case(args: argparse.Namespace) -> None:
    """Run one synthetic paper case with its released settings."""
    case = args.case
    config_path = Path("configs") / f"{case}.json"
    if not config_path.is_file():
        raise FileNotFoundError(
            f"Case config not found: {config_path}. Run this command from the repository root."
        )
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if case == "au":
        if args.sample is not None:
            raise ValueError("AU contains one bundled case and does not take a sample index")
        output_path = Path(config["output"])
        sample_name = str(config["sample"])
        sample_index = None
    else:
        if args.sample is None or args.sample < 0:
            raise ValueError(f"{case} requires a non-negative sample index")
        reference_index = int(config["sample_index"])
        output_path = Path(config["output"]).parent / f"{case}_sample_{args.sample:04d}"
        sample_name = (
            str(config["sample"]) if args.sample == reference_index else f"sample_{args.sample:04d}"
        )
        sample_index = args.sample
    _reconstruct(
        argparse.Namespace(
            config=config_path,
            input=None,
            output=output_path,
            sample_index=sample_index,
            sample_name=sample_name,
            device=args.device,
            iterations=args.iterations,
            no_plot=args.no_plot,
        )
    )


def _run_fresnel_target(args: argparse.Namespace) -> None:
    """Run the requested paper frequencies for one measured Fresnel target."""
    manifest = json.loads(FRESNEL_CASES_FILE.read_text(encoding="utf-8"))
    selected = manifest[args.target]
    frequencies = (
        tuple(f"{value}GHz" for value in args.frequencies)
        if args.frequencies
        else FRESNEL_FREQUENCIES
    )
    if len(set(frequencies)) != len(frequencies):
        raise ValueError("List each Fresnel frequency only once")

    cases = []
    source_display = None
    sensor_radius_m = None
    for frequency in frequencies:
        config_name = selected.get(frequency)
        if config_name is None:
            raise FileNotFoundError(
                f"No configuration JSON for {args.target} at {frequency} "
                f"in {FRESNEL_CASES_FILE}; available: {', '.join(selected)}"
            )
        config_path = Path(config_name)
        if not config_path.is_file():
            raise FileNotFoundError(
                f"Configuration JSON missing for {args.target} at {frequency}: {config_path}"
            )
        config = json.loads(config_path.read_text(encoding="utf-8"))
        input_path = _resolved_path(config["input"])
        if (
            config["case"] != "fresnel"
            or input_path.stem != args.target
            or float(config["frequency_ghz"]) != float(frequency.removesuffix("GHz"))
        ):
            raise ValueError(f"Invalid Fresnel configuration: {config_path}")
        if not input_path.is_file():
            raise FileNotFoundError(f"Fresnel data not found: {input_path}. See README.md.")
        if source_display is None:
            source_display = str(config["input"])
        elif str(config["input"]) != source_display:
            raise ValueError(f"Fresnel frequencies must share one input file: {config_path}")
        radius = float(config["sensor_radius_m"])
        if sensor_radius_m is None:
            sensor_radius_m = radius
        elif radius != sensor_radius_m:
            raise ValueError(f"Fresnel frequencies must share one sensor radius: {config_path}")
        cases.append((frequency, config_path, input_path))

    output_root = _resolved_path(args.output or Path("outputs") / f"fresnel_{args.target}")
    output_root.mkdir(parents=True, exist_ok=True)
    summary = {
        "dataset": "fresnel",
        "target": args.target,
        "input": source_display,
        "sensor_radius_m": sensor_radius_m,
        "requested_frequencies_ghz": [int(value.removesuffix("GHz")) for value in frequencies],
        "status": "incomplete",
        "results": {},
    }
    summary_path = output_root / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    for frequency, config_path, input_path in cases:
        result_dir = output_root / frequency
        _reconstruct(
            argparse.Namespace(
                config=config_path,
                input=input_path,
                output=result_dir,
                sample_name=None,
                device=args.device,
                iterations=None,
                no_plot=args.no_plot,
            )
        )
        metrics = json.loads((result_dir / "metrics.json").read_text(encoding="utf-8"))
        summary["results"][frequency] = {
            "config": str(config_path),
            "output": str(result_dir),
            "ssim": metrics["ssim"],
            "psnr_db": metrics["psnr"],
            "snr_db": metrics["snr_db"],
            "rrmse": metrics["rrmse"],
            "rel_data_error": metrics["rel_data_error"],
        }
        summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    summary["status"] = "complete"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    selected_frequencies = ", ".join(frequencies)
    print(f"Fresnel {args.target}: {selected_frequencies} results saved to {summary_path}")


def _benchmark(args: argparse.Namespace) -> None:
    """Evaluate the first synthetic images with SingleTX's sequential noise."""
    config_path = _resolved_path(args.config or Path("configs") / BENCHMARK_CONFIG_FILES[args.case])
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config["case"] != args.case:
        raise ValueError(f"Benchmark config is for {config['case']}, not {args.case}")
    source = _resolved_path(config["input"])
    if not source.is_file():
        raise FileNotFoundError(
            f"Official {args.case} test pickle not found: {source}. See README.md."
        )
    if args.first < 1:
        raise ValueError("--first must be positive")
    device = args.device or config.get("device", "cuda")
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    precision = config.get("precision", "single")
    if precision not in {"single", "double"}:
        raise ValueError(f"Unsupported precision: {precision}")
    dtype = torch.complex64 if precision == "single" else torch.complex128
    options = paper_options(_case_settings(config), SolverControls())

    def run(output_dir: Path):
        return run_singletx_benchmark(
            args.case,
            source,
            output_dir,
            options,
            first=args.first,
            device=str(device),
            dtype=dtype,
        )

    if args.output is None:
        with tempfile.TemporaryDirectory(prefix="gaugal-benchmark-") as temporary:
            means = run(Path(temporary))
    else:
        means = run(_resolved_path(args.output))
    print(
        f"{args.case.capitalize()} first {means.count} mean: SSIM={means.ssim:.6f}, "
        f"RRMSE={means.rrmse:.6f}, PSNR={means.psnr:.3f} dB"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gaugal")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run", help="run one synthetic paper case")
    run.add_argument("case", choices=RUN_CASES)
    run.add_argument("sample", nargs="?", type=int, help="required for MNIST and Cylinder")
    run.add_argument("--device", choices=("cuda", "cpu"), default=None)
    run.add_argument(
        "--iterations", type=int, default=None, help="smoke-test override; not a paper result"
    )
    run.add_argument("--no-plot", action="store_true")
    run.set_defaults(function=_run_case)
    fresnel = commands.add_parser(
        "fresnel", help="run selected GHz frequencies for one Fresnel target"
    )
    fresnel.add_argument("target", choices=FRESNEL_TARGETS)
    fresnel.add_argument(
        "frequencies",
        nargs="*",
        type=int,
        metavar="GHz",
        help="choose from 3, 4, and 5 (default: all three)",
    )
    fresnel.add_argument("--output", type=Path, default=None, help="result directory")
    fresnel.add_argument("--device", choices=("cuda", "cpu"), default=None)
    fresnel.add_argument("--no-plot", action="store_true")
    fresnel.set_defaults(function=_run_fresnel_target)
    benchmark = commands.add_parser(
        "benchmark", help="evaluate synthetic samples with SingleTX's sequential noise stream"
    )
    benchmark.add_argument("case", choices=("mnist", "cylinder"))
    benchmark.add_argument("--first", type=int, default=100, help="number of samples from index 0")
    benchmark.add_argument("--device", choices=("cuda", "cpu"), default=None)
    benchmark.add_argument(
        "--config", type=Path, default=None, help="override the dataset benchmark settings"
    )
    benchmark.add_argument(
        "--output", type=Path, default=None, help="keep local per-case results (default: temporary)"
    )
    benchmark.set_defaults(function=_benchmark)
    reconstruct = commands.add_parser("reconstruct-2d", help="run a configured paper case")
    reconstruct.add_argument("config", type=Path)
    reconstruct.add_argument(
        "--input", type=Path, default=None, help="override the official test pickle or .exp path"
    )
    reconstruct.add_argument("--sample-index", type=int, default=None)
    reconstruct.add_argument(
        "--output", type=Path, default=None, help="override the result directory"
    )
    reconstruct.add_argument("--device", choices=("cuda", "cpu"), default=None)
    reconstruct.add_argument(
        "--iterations", type=int, default=None, help="smoke-test override; not a paper result"
    )
    reconstruct.add_argument("--no-plot", action="store_true")
    reconstruct.set_defaults(function=_reconstruct)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.function(args)
    except FileNotFoundError as error:
        parser.exit(2, f"gaugal: error: {error}\n")


if __name__ == "__main__":
    main()
