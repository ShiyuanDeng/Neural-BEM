"""Regularization weights and schedules shared by the 2-D reconstruction."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .fresnel import FresnelModel
from .operators import (
    complex_norm,
)


@dataclass
class ReconstructionOptions:
    """Optimizer and regularization controls."""

    num_iter: int = 500
    alpha: float = 0.96
    base_lambda_scale: float = 5e-5
    lambda_scale: float = 0.25
    lambda_schedule: str = "fixed"
    lambda_final_fraction: float = 1.0
    lambda_decay_start_fraction: float = 0.5
    pcg_tol: float = 1e-6
    pcg_max_iter: int = 1000
    tv_max_iter: int = 100
    tv_schedule: str = "fixed"
    tv_min_iter: int = 20
    tv_mid_iter: int = 50
    tv_mid_fraction: float = 0.5
    tv_full_fraction: float = 0.85
    tv_tol: float = 1e-4
    contrast_max: float = float("inf")


def _lambda_value(model: FresnelModel, opts: ReconstructionOptions) -> float:
    """Scale TV strength by half the measured-data energy."""
    data_norm = float(complex_norm(model.data).detach().cpu())
    return opts.base_lambda_scale * 0.5 * data_norm * data_norm * opts.lambda_scale


def _lambda_value_for_iteration(
    base_lam: float, opts: ReconstructionOptions, ind_iter: int
) -> float:
    schedule = str(opts.lambda_schedule)
    if schedule == "fixed":
        return float(base_lam)
    final_fraction = max(0.0, float(opts.lambda_final_fraction))
    start_fraction = min(max(float(opts.lambda_decay_start_fraction), 0.0), 1.0)
    start_iter = 1 + int(round(start_fraction * max(opts.num_iter - 1, 0)))
    if ind_iter <= start_iter or opts.num_iter <= start_iter:
        scale = 1.0
    else:
        t = (ind_iter - start_iter) / max(opts.num_iter - start_iter, 1)
        t = min(max(t, 0.0), 1.0)
        if schedule in {"linear-decay", "decay"}:
            scale = 1.0 - (1.0 - final_fraction) * t
        elif schedule == "cosine-decay":
            scale = final_fraction + (1.0 - final_fraction) * 0.5 * (1.0 + np.cos(np.pi * t))
        elif schedule == "step-decay":
            scale = final_fraction
        else:
            raise ValueError(f"Unknown lambda schedule: {opts.lambda_schedule}")
    return float(base_lam) * float(scale)


def _tv_max_iter_for_iteration(
    opts: ReconstructionOptions, ind_iter: int, *, force_full: bool = False
) -> int:
    max_iter = max(1, int(opts.tv_max_iter))
    schedule = str(opts.tv_schedule)
    if schedule == "fixed" or force_full:
        return max_iter
    if schedule != "adaptive":
        raise ValueError(f"Unknown TV schedule: {opts.tv_schedule}")

    min_iter = max(1, min(max_iter, int(opts.tv_min_iter)))
    mid_iter = max(min_iter, min(max_iter, int(opts.tv_mid_iter)))
    if opts.num_iter <= 1:
        progress = 1.0
    else:
        progress = (ind_iter - 1) / max(1, opts.num_iter - 1)
    mid_fraction = float(opts.tv_mid_fraction)
    full_fraction = float(opts.tv_full_fraction)
    if not (0.0 <= mid_fraction <= 1.0 and 0.0 <= full_fraction <= 1.0):
        raise ValueError("TV schedule fractions must be in [0, 1]")
    if full_fraction < mid_fraction:
        raise ValueError("tv_full_fraction must be >= tv_mid_fraction")
    if progress < mid_fraction:
        return min_iter
    if progress < full_fraction:
        return mid_iter
    return max_iter
