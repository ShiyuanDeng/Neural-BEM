"""Load SingleTX fields and map column-first cells to row-major images."""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import torch

from .synthetic import SyntheticScatteringModel


def load_singletx_pickle_case(
    source: str | Path,
    *,
    sample_index: int,
    file_name: str,
    device: str | torch.device = "cuda",
    dtype: torch.dtype = torch.complex64,
    domain_operator: str = "dense",
    test_noise_ratio: float = 0.0,
    noise_seed: int = 1000,
) -> SyntheticScatteringModel:
    """Load one clean official test sample and add its deterministic noise."""

    if domain_operator not in {"dense", "kernel"}:
        raise ValueError(f"Unknown domain operator mode: {domain_operator}")
    if dtype not in (torch.complex64, torch.complex128):
        raise ValueError("dtype must be torch.complex64 or torch.complex128")

    with Path(source).open("rb") as stream:
        archive = pickle.load(stream)  # nosec: only load the trusted official download
    raw = archive["data"]
    params = archive["params"]
    sample_count = int(params["num_groups"])
    if sample_count != len(raw["epsilon_gt"]):
        raise ValueError("Inconsistent sample count in SingleTX pickle")
    if not 0 <= sample_index < sample_count:
        raise IndexError(f"sample_index {sample_index} is outside the test set")

    e_s = raw["E_s_real"][sample_index] + 1j * raw["E_s_imag"][sample_index]
    e_s = _apply_eisp_measurement_noise(
        e_s,
        test_noise_ratio=float(test_noise_ratio),
        noise_seed=int(noise_seed),
    )
    receiver_count = e_s.shape[0]
    xy_r = raw.get("xy_r", np.zeros((receiver_count, 2)))

    return _build_eisp_matrix_model(
        file_name=file_name,
        epsilon=np.asarray(raw["epsilon_gt"][sample_index], dtype=np.float64),
        x_dom=np.asarray(raw["x_dom"], dtype=np.float64),
        y_dom=np.asarray(raw["y_dom"], dtype=np.float64),
        e_inc=raw["E_inc_real"] + 1j * raw["E_inc_imag"],
        e_s=e_s,
        phi=raw["Phi_mat_real"] + 1j * raw["Phi_mat_imag"],
        r_mat=raw["R_mat_real"] + 1j * raw["R_mat_imag"],
        xy_t=np.asarray(raw["xy_t"], dtype=np.float64),
        xy_r=np.asarray(xy_r, dtype=np.float64),
        lam_0=float(params["lam_0"]),
        max_dom=float(params["MAX"]),
        device=device,
        dtype=dtype,
        domain_operator=domain_operator,
    )


def _build_eisp_matrix_model(
    *,
    file_name: str,
    epsilon: np.ndarray,
    x_dom: np.ndarray,
    y_dom: np.ndarray,
    e_inc: np.ndarray,
    e_s: np.ndarray,
    phi: np.ndarray,
    r_mat: np.ndarray,
    xy_t: np.ndarray,
    xy_r: np.ndarray,
    lam_0: float,
    max_dom: float,
    device: str | torch.device,
    dtype: torch.dtype,
    domain_operator: str,
) -> SyntheticScatteringModel:
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    device = torch.device(device)
    mx = int(epsilon.shape[0])
    if epsilon.shape != (mx, mx):
        raise ValueError(f"Expected square epsilon array, got {epsilon.shape}")
    if x_dom.shape != (mx, mx) or y_dom.shape != (mx, mx):
        raise ValueError("x_dom and y_dom must both be Mx-by-Mx arrays")
    if e_s.ndim != 2:
        raise ValueError(f"E_s must have shape (N_rec, N_inc), got {e_s.shape}")
    if e_inc.shape != (mx * mx, e_s.shape[1]):
        raise ValueError(f"E_inc shape {e_inc.shape} is not compatible with E_s shape {e_s.shape}")
    if r_mat.shape[-1] != mx * mx:
        raise ValueError(f"R_mat final axis must have {mx * mx} cells, got {r_mat.shape}")
    if xy_t.ndim != 2 or xy_t.shape != (e_s.shape[1], 2):
        raise ValueError(f"xy_t must have shape {(e_s.shape[1], 2)}, got {xy_t.shape}")
    if xy_r.size and (xy_r.ndim != 2 or xy_r.shape != (e_s.shape[0], 2)):
        raise ValueError(f"xy_r must have shape {(e_s.shape[0], 2)}, got {xy_r.shape}")

    # The stored Phi/R/E_inc arrays number pixels column-first; images and
    # Gaussian basis weights in the optimizer number them row-first.
    perm = np.arange(mx * mx).reshape(mx, mx, order="C").ravel(order="F")
    inv_perm = np.empty_like(perm)
    inv_perm[perm] = np.arange(perm.size)

    x_unique = np.unique(x_dom)
    y_unique = np.unique(y_dom)
    dx = _mean_grid_spacing(x_unique, fallback=2.0 * max_dom / (mx - 1))
    dy = _mean_grid_spacing(y_unique, fallback=2.0 * max_dom / (mx - 1))
    length = float(max(np.max(x_unique) - np.min(x_unique), np.max(y_unique) - np.min(y_unique)))

    frequency_ghz = 3.0e8 / lam_0 / 1e9
    kb = 2.0 * np.pi / lam_0
    omega = kb * 3.0e8
    eps0 = 8.85e-12
    # J = (-i omega eps0 dA) * contrast * E_total. Keep this prefactor
    # identical for the domain and sensor operators.
    interaction_scale = -1j * omega * eps0 * dx * dy

    if domain_operator == "dense":
        dense_g_np = interaction_scale * phi[np.ix_(inv_perm, inv_perm)]
        domain_kernel_fft = torch.empty((0, 0), device=device, dtype=dtype)
    else:
        dense_g_np = np.empty(
            (0, 0), dtype=np.complex64 if dtype == torch.complex64 else np.complex128
        )
        kernel_pad = _domain_kernel_pad_from_phi(
            phi,
            inv_perm,
            mx,
            interaction_scale,
            dtype=dtype,
        )
        domain_kernel_fft = torch.fft.fft2(torch.as_tensor(kernel_pad, device=device, dtype=dtype))

    if r_mat.ndim == 2:
        dense_h_np = interaction_scale * r_mat[:, inv_perm]
    elif r_mat.ndim == 3:
        dense_h_np = interaction_scale * r_mat[:, :, inv_perm]
    else:
        raise ValueError(f"Unsupported R_mat shape: {r_mat.shape}")

    truth_t = torch.as_tensor(epsilon - 1.0, device=device, dtype=real_dtype)
    xx_t = torch.as_tensor(x_dom, device=device, dtype=real_dtype)
    yy_t = torch.as_tensor(y_dom, device=device, dtype=real_dtype)
    x_t = torch.as_tensor(x_unique, device=device, dtype=real_dtype)
    y_t = torch.as_tensor(y_unique, device=device, dtype=real_dtype)
    pixel_points = torch.stack([xx_t.reshape(-1), yy_t.reshape(-1)], dim=1)
    data_tr = e_s.T
    uinc = e_inc[inv_perm].T

    x_transmit = torch.as_tensor(xy_t[:, 0], device=device, dtype=real_dtype)
    y_transmit = torch.as_tensor(xy_t[:, 1], device=device, dtype=real_dtype)
    if xy_r.size:
        x_receive = torch.as_tensor(xy_r[:, 0], device=device, dtype=real_dtype)
        y_receive = torch.as_tensor(xy_r[:, 1], device=device, dtype=real_dtype)
    else:
        x_receive = torch.zeros(data_tr.shape[1], device=device, dtype=real_dtype)
        y_receive = torch.zeros(data_tr.shape[1], device=device, dtype=real_dtype)

    return SyntheticScatteringModel(
        file_name=file_name,
        frequency_ghz=frequency_ghz,
        wavelength=lam_0,
        kb=kb,
        length=length,
        nx=mx,
        ny=mx,
        dx=dx,
        dy=dy,
        x=x_t,
        y=y_t,
        xx=xx_t,
        yy=yy_t,
        data=torch.as_tensor(data_tr, device=device, dtype=dtype),
        receiver_mask=torch.ones(data_tr.shape, device=device, dtype=torch.bool),
        uinc=torch.as_tensor(uinc, device=device, dtype=dtype),
        nominal_truth=truth_t,
        dense_g=torch.as_tensor(dense_g_np, device=device, dtype=dtype),
        dense_h=torch.as_tensor(dense_h_np, device=device, dtype=dtype),
        pixel_points=pixel_points,
        x_transmit=x_transmit,
        y_transmit=y_transmit,
        x_receive=x_receive,
        y_receive=y_receive,
        domain_kernel_fft=domain_kernel_fft,
    )


def _apply_eisp_measurement_noise(
    values: np.ndarray,
    *,
    test_noise_ratio: float,
    noise_seed: int,
) -> np.ndarray:
    """Add deterministic noise with separate real and imaginary draws."""
    values = np.asarray(values, dtype=np.complex128)
    if test_noise_ratio <= 0.0:
        return values
    rng = np.random.RandomState(noise_seed)
    energy = float(np.sqrt(np.mean(values.real**2 + values.imag**2)) / np.sqrt(2.0))
    real_noise = energy * test_noise_ratio * rng.randn(*values.shape)
    imag_noise = energy * test_noise_ratio * rng.randn(*values.shape)
    return values.real + real_noise + 1j * (values.imag + imag_noise)


def _mean_grid_spacing(values: np.ndarray, *, fallback: float) -> float:
    values = np.unique(values)
    if values.size < 2:
        return float(fallback)
    return float(np.mean(np.abs(np.diff(values))))


def _domain_kernel_pad_from_phi(
    phi: np.ndarray,
    inv_perm: np.ndarray,
    grid_size: int,
    interaction_scale: complex,
    *,
    dtype: torch.dtype,
) -> np.ndarray:
    """Extract a translation-invariant 2N-by-2N FFT kernel from native Phi."""
    np_dtype = np.complex64 if dtype == torch.complex64 else np.complex128
    padded_size = 2 * grid_size
    kernel_pad = np.zeros((padded_size, padded_size), dtype=np_dtype)
    for dy in range(-(grid_size - 1), grid_size):
        iy = max(dy, 0)
        jy = iy - dy
        for dx in range(-(grid_size - 1), grid_size):
            ix = max(dx, 0)
            jx = ix - dx
            row = iy * grid_size + ix
            col = jy * grid_size + jx
            src_row = inv_perm[row]
            src_col = inv_perm[col]
            # Modulo indexing puts negative displacements at the end of the
            # FFT buffer without changing the original Green coefficients.
            kernel_pad[dy % padded_size, dx % padded_size] = (
                interaction_scale * phi[src_row, src_col]
            )
    return kernel_pad
